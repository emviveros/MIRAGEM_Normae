import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 
import netP5.*; 
import oscP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class normaeProtoInterface_01_Shiyozi extends PApplet {

/********************************************************************************************
 * Protótipo de Interface para Normae_12 - Shiyozi
 * Interface de 1 range slider com seletor de porta para acionamento
 * e desacionamento de módulo de relé
 *
 *******************************************************************************************/

/* ToDo
 *    - Gerar elemento de interface, 2 botões (+ e -)
 *       que vão incrementar ou decrementar o último elemento modificado detectado pelo
 *       objeto sentinela -> adicionar funções em sentinela.dedoDuro()
 *
 */

//===========================================================================================
//                            Declaração de Bibliotecas
//===========================================================================================

//import gohai.simpletouch.*;    //biblioteca de entradas multi-touch
            //biblioteca de eLementos da interface
                //dependência para oscP5
                //biblioteca de protocolo OSC


//===========================================================================================
//                            Inicialização de objetos
//===========================================================================================

OscP5 oscP5;    //referente a biblioteca para comunicação OSC
NetAddress enderecoNormae;    //para inicialização de endereço de rede da controladora Normae
NetAddress enderecoMac;    //para inicialização de endereço de rede do computador para debug

ControlP5 cp5;    //referente a biblioteca controlP5

Textlabel tituloPortas;    //texto com título do seletor de porta de saída

Textlabel tituloTensao;    //texto com título do seletor de tensão da porta selecionada

Textlabel indicePortas;    //texto com o número de cada porta para seletor de portas de saída

RadioButton portas;    //objeto gráfico de seleção de porta de saída

Numberbox inTempoMaximo;     //objeto gráfico de entrada de tempo máximo
Knob knobTempoMaximo;    //objeto gráfico de entrada de tempo máximo

Range rangeEvento1;    //objeto gráfico de entrada de tempo inicial e final de cada evento

Sentinela sentinela;    //objeto que armazena dados de alguns elementos da interface

//===========================================================================================
//                               Variáveis Globais
//===========================================================================================

int myColorBackground = 100;    //cor de fundo da tela de interface gráfica

boolean[] toggleValue = new boolean[12];    //seletor de tensão da porta (12V-24V)

float[] evento1Min = new float[12]; float[] evento2Min = new float[12];
float[] evento3Min = new float[12]; float[] evento4Min = new float[12];
float[] evento5Min = new float[12];

float[] evento1Max = new float[12]; float[] evento2Max = new float[12];
float[] evento3Max = new float[12]; float[] evento4Max = new float[12];
float[] evento5Max = new float[12];

float tempoTotal;

float rangeMin = 0.0f;    //valor mínimo de cada slider
float rangeMax = 7000.00f;    //valor máximo de cada slider

int porta1 = 0, porta2 = 0, porta3 = 0, porta4 = 0,    //contém o estado do botões
    porta5 = 0, porta6 = 0, porta7 = 0, porta8 = 0,    //das  Portas de Saída.
    porta9 = 0, porta10 = 0, porta11 = 0, porta12 = 0;
    
int portaAtiva;
int toogleTensaoPosX = 60;    //posição X da interface de seleção de Porta de Saída
int toogleTensaoPosY = 95;    //posição Y da interface de seleção de Porta de Saída


//===========================================================================================
//                       Configuração da Interface (Geração)
//===========================================================================================
public void setup()
{
  
  noStroke();

  sentinela = new Sentinela(0, 0, 0);
  
  oscP5 = new OscP5(this,7777);    //ouvindo na porta 7777
  enderecoNormae = new NetAddress("169.254.81.77",5555);//endereço comunicação LAN com Normae
  enderecoMac =  new NetAddress("192.168.0.200",5555);//endereço p teste mac
  
  cp5 = new ControlP5(this);
 
  gerarInterface("default", 1);
  //gerarInterface("Porta1", 1);
  gerarInterface("Porta2", 2);
  gerarInterface("Porta3", 3);
  gerarInterface("Porta4", 4);
  gerarInterface("Porta5", 5);
  gerarInterface("Porta6", 6);
  gerarInterface("Porta7", 7);
  gerarInterface("Porta8", 8);
  gerarInterface("Porta9", 9);
  gerarInterface("Porta10", 10);
  gerarInterface("Porta11", 11);
  gerarInterface("Porta12", 12);
  
  gerarTabs();
}


//===========================================================================================
//                                   Programa
//===========================================================================================
public void draw()
{
  background(60);
}


//===========================================================================================
//                           Construção de mensagens OSC
//===========================================================================================

  //////////////////////////////////////////////////////////////////////////////////////
 /// Envia vetores de tempo mínimo e máximo de EVENTOS e INÍCIO da operação por OSC ///
//////////////////////////////////////////////////////////////////////////////////////

//msg: /setar/evento/int(numeroDoEvento)/Porta/int(numeroDaPorta)/
//      tempoInicio/String(tempoInicio)/tempoFinal/String(tempoFinal)

public void setarEventos()    // mensagens p/ setar Evento em todas as Portas
{
  setarTempoTotal_e_AtivacaoDeEventos();
  
  String tempoInicio;
  String tempoFinal;
  
    for ( int numeroDoEvento = 1; numeroDoEvento <= 7; numeroDoEvento++)
    {
      for ( int i = 0; i <= 11; i++)
      {
      OscMessage setandoEvento = new OscMessage("/setar/evento");
      setandoEvento.add(numeroDoEvento);
      setandoEvento.add("Porta");
      setandoEvento.add(i + 1);                   // porta a ser setada
        switch(numeroDoEvento)
        {
          case 1:
          setandoEvento.add("tempoInicio");
          tempoInicio = str(evento1Min[i]);   // tempo de inicio do evento
          setandoEvento.add(tempoInicio);
          setandoEvento.add("tempoFinal");
          tempoFinal = str(evento1Max[i]);    // tempo final do evento
          setandoEvento.add(tempoFinal);
          break;
          
        case 2:
          setandoEvento.add("tempoInicio");
          tempoInicio = str(evento2Min[i]);
          setandoEvento.add(tempoInicio);
          setandoEvento.add("tempoFinal");
          tempoFinal = str(evento2Max[i]);
          setandoEvento.add(tempoFinal);
          break;
          
        case 3:
          setandoEvento.add("tempoInicio");
          tempoInicio = str(evento3Min[i]);
          setandoEvento.add(tempoInicio);
          setandoEvento.add("tempoFinal");
          tempoFinal = str(evento3Max[i]);
          setandoEvento.add(tempoFinal);
          break;
          
        case 4:
          setandoEvento.add("tempoInicio");
          tempoInicio = str(evento4Min[i]);
          setandoEvento.add(tempoInicio);
          setandoEvento.add("tempoFinal");
          tempoFinal = str(evento4Max[i]);
          setandoEvento.add(tempoFinal);
          break;
          
        case 5:
          setandoEvento.add("tempoInicio");
          tempoInicio = str(evento5Min[i]);
          setandoEvento.add(tempoInicio);
          setandoEvento.add("tempoFinal");
          tempoFinal = str(evento5Max[i]);
          setandoEvento.add(tempoFinal);
          break;
        } 
      //oscP5.send(setandoEvento, enderecoNormae);
      oscP5.send(setandoEvento, enderecoMac);
      delay(20);
      }
    }
}


  ///////////////////////////////////////////////////////////////////////////
 /// Envia dado de tempo total e ativação de Eventos da operação por OSC ///
///////////////////////////////////////////////////////////////////////////

//msg: /setar/tempoTotal/String(tempoTotal)

public void setarTempoTotal_e_AtivacaoDeEventos()    // mensagens p/ setar tempoTotal
{                                             //  e Ativação de Eventos
  String tempoMaximo;
  float[] maximoMesmo = new float[5];
  
  OscMessage setandoTempoTotal = new OscMessage("/setar/tempoTotal");
  maximoMesmo[0] = max(evento1Max);
  maximoMesmo[1] = max(evento2Max);
  maximoMesmo[2] = max(evento3Max);
  maximoMesmo[3] = max(evento4Max);
  maximoMesmo[4] = max(evento5Max);
  tempoTotal = max(maximoMesmo);
  tempoMaximo = str(tempoTotal);
  
  setandoTempoTotal.add(tempoMaximo);
  //oscP5.send(setandoTempoTotal, enderecoNormae);
  oscP5.send(setandoTempoTotal, enderecoMac);
  
  for ( int i = 0; i <= 4; i++)
  {
    OscMessage setandoEventos = new OscMessage("/setar/modoAtivo");
    if ( maximoMesmo[i] == 0)
    {
      setandoEventos.add(0);
    }
    else
    {
      setandoEventos.add(1);
    }
    setandoEventos.add("evento");
    setandoEventos.add(i + 1);
    //oscP5.send(setandoEventos, enderecoNormae);
    oscP5.send(setandoEventos, enderecoMac);
  }
}


  //////////////////////////////////////////////////
 /// Envia mensagem de Iniciar Operação via OSC ///
//////////////////////////////////////////////////

//msg: /iniciar/int(1 para começar)

public void iniciarOperacao()
{
  setarEventos();    //manda OSC bundle com todas as mensagens para setar os Eventos  
  OscMessage iniciarOperacao = new OscMessage("/iniciar");
  iniciarOperacao.add(1);
  //oscP5.send(iniciarOperacao, enderecoNormae);
  oscP5.send(iniciarOperacao, enderecoMac);
}


  /////////////////////////////////////////////////////////////
 /// Envia controle de tensão dos Reles nas Portas via OSC ///
/////////////////////////////////////////////////////////////

//msg: /setar/tensao/Porta/(int (1-12))/para/(boolean (true/false))

public void setarTensaoPorta(int numeroDaPorta, boolean estadoDoToggle)
{
  OscMessage setarTensao = new OscMessage("/setar/tensao");
  if( estadoDoToggle == true)
  {
    print("Enviando mensagem com Porta = " + numeroDaPorta + ", toggle = " + estadoDoToggle);
    print("\n");
    setarTensao.add("Porta");
    setarTensao.add(numeroDaPorta);
    setarTensao.add("para");
    setarTensao.add(12);
    oscP5.send(setarTensao, enderecoNormae);
    oscP5.send(setarTensao, enderecoMac);
  }
  else if ( estadoDoToggle == false )
  {
    print("Enviando mensagem com Porta = " + numeroDaPorta + ", toggle = " + estadoDoToggle);
    print("\n");
    setarTensao.add("Porta");
    setarTensao.add(numeroDaPorta);
    setarTensao.add("para");
    setarTensao.add(24);
    oscP5.send(setarTensao, enderecoNormae);
    oscP5.send(setarTensao, enderecoMac);
  }
}


//===========================================================================================
//                           Recebimento de mensagens OSC
//===========================================================================================

/* incoming osc message are forwarded to the oscEvent method. */
public void oscEvent(OscMessage theOscMessage)
{
  /* print the address pattern and the typetag of the received OscMessage */
  print( "### received an osc message." );
  print( " addrpattern: "+theOscMessage.addrPattern() );
  print( "/"+theOscMessage.get(0).intValue() );
  println( " typetag: "+theOscMessage.typetag() );
}


//===========================================================================================
//               Controle de Eventos dos Elementos da Interface
//===========================================================================================

public void controlEvent(ControlEvent theEvent)
{
  //////////////////////////////////////////
 // Gerenciando Range Sliders de EVENTOS //
//////////////////////////////////////////

  if(theEvent.isFrom(cp5.getController("evento_1_default")))    //referente evento1 Porta 1
    {
      int evento = 1;
      int porta = 1;
      String nome = "Evento_1_default";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta2")))    //referente Porta 2
    {
      int evento = 1;
      int porta = 2;
      String nome = "Evento_1_Porta2";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta3")))    //referente Porta 3
    {
      int evento = 1;
      int porta = 3;
      String nome = "Evento_1_Porta3";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta4")))    //referente Porta 4
    {
      int evento = 1;
      int porta = 4;
      String nome = "Evento_1_Porta4";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta5")))    //referente Porta 5
    {
      int evento = 1;
      int porta = 5;
      String nome = "Evento_1_Porta5";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta6")))    //referente Porta 6
    {
      int evento = 1;
      int porta = 6;
      String nome = "Evento_1_Porta6";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta7")))    //referente Porta 7
    {
      int evento = 1;
      int porta = 7;
      String nome = "Evento_1_Porta7";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta8")))    //referente Porta 8
    {
      int evento = 1;
      int porta = 8;
      String nome = "Evento_1_Porta8";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta9")))    //referente Porta 9
    {
      int evento = 1;
      int porta = 9;
      String nome = "Evento_1_Porta9";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta10")))    //referente Porta 10
    {
      int evento = 1;
      int porta = 10;
      String nome = "Evento_1_Porta10";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta11")))    //referente Porta 11
    {
      int evento = 1;
      int porta = 11;
      String nome = "Evento_1_Porta11";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta12")))    //referente Porta 12
    {
      int evento = 1;
      int porta = 12;
      String nome = "Evento_1_Porta12";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    
   ////////////////////////////     EVENTO 2       /////////////////////////////////////   
    if(theEvent.isFrom(cp5.getController("evento_2_default")))  //referente evento2 Porta 1
    {
      int evento = 2;
      int porta = 1;
      String nome = "Evento_2_default";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
   
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta2")))    //referente Porta 2
    {
      int evento = 2;
      int porta = 2;
      String nome = "Evento_2_Porta2";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta3")))    //referente Porta 3
    {
      int evento = 2;
      int porta = 3;
      String nome = "Evento_2_Porta3";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta4")))    //referente Porta 4
    {
      int evento = 2;
      int porta = 4;
      String nome = "Evento_2_Porta4";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta5")))    //referente Porta 5
    {
      int evento = 2;
      int porta = 5;
      String nome = "Evento_2_Porta5";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta6")))    //referente Porta 6
    {
      int evento = 2;
      int porta = 6;
      String nome = "Evento_2_Porta6";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta7")))    //referente Porta 7
    {
      int evento = 2;
      int porta = 7;
      String nome = "Evento_2_Porta7";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta8")))    //referente Porta 8
    {
      int evento = 2;
      int porta = 8;
      String nome = "Evento_2_Porta8";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta9")))    //referente Porta 9
    {
      int evento = 2;
      int porta = 9;
      String nome = "Evento_2_Porta9";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta10")))    //referente Porta 10
    {
      int evento = 2;
      int porta = 10;
      String nome = "Evento_2_Porta10";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta11")))    //referente Porta 11
    {
      int evento = 2;
      int porta = 11;
      String nome = "Evento_2_Porta11";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta12")))    //referente Porta 12
    {
      int evento = 2;
      int porta = 12;
      String nome = "Evento_2_Porta12";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    
   ////////////////////////////     EVENTO 3       /////////////////////////////////////       
    if(theEvent.isFrom(cp5.getController("evento_3_default")))  //referente evento3 Porta 1
    {
      int evento = 3;
      int porta = 1;
      String nome = "Evento_3_default";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta2")))    //referente Porta 2
    {
      int evento = 3;
      int porta = 2;
      String nome = "Evento_3_Porta2";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta3")))    //referente Porta 3
    {
      int evento = 3;
      int porta = 3;
      String nome = "Evento_3_Porta3";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta4")))    //referente Porta 4
    {
      int evento = 3;
      int porta = 4;
      String nome = "Evento_3_Porta4";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta5")))    //referente Porta 5
    {
      int evento = 3;
      int porta = 5;
      String nome = "Evento_3_Porta5";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta6")))    //referente Porta 6
    {
      int evento = 3;
      int porta = 6;
      String nome = "Evento_3_Porta6";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta7")))    //referente Porta 7
    {
      int evento = 3;
      int porta = 7;
      String nome = "Evento_3_Porta7";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta8")))    //referente Porta 8
    {
      int evento = 3;
      int porta = 8;
      String nome = "Evento_3_Porta8";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta9")))    //referente Porta 9
    {
      int evento = 3;
      int porta = 9;
      String nome = "Evento_3_Porta9";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta10")))    //referente Porta 10
    {
      int evento = 3;
      int porta = 10;
      String nome = "Evento_3_Porta10";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta11")))    //referente Porta 11
    {
      int evento = 3;
      int porta = 11;
      String nome = "Evento_3_Porta11";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta12")))    //referente Porta 12
    {
      int evento = 3;
      int porta = 12;
      String nome = "Evento_3_Porta12";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    ////////////////////////////     EVENTO 4       /////////////////////////////////////
    if(theEvent.isFrom(cp5.getController("evento_4_default")))    //referente evento4 Porta 1
    {
      int evento = 4;
      int porta = 1;
      String nome = "Evento_4_default";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta2")))    //referente Porta 2
    {
      int evento = 4;
      int porta = 2;
      String nome = "Evento_4_Porta2";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta3")))    //referente Porta 3
    {
      int evento = 4;
      int porta = 3;
      String nome = "Evento_4_Porta3";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta4")))    //referente Porta 4
    {
      int evento = 4;
      int porta = 4;
      String nome = "Evento_4_Porta4";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta5")))    //referente Porta 5
    {
      int evento = 4;
      int porta = 5;
      String nome = "Evento_4_Porta5";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta6")))    //referente Porta 6
    {
      int evento = 4;
      int porta = 6;
      String nome = "Evento_4_Porta6";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta7")))    //referente Porta 7
    {
      int evento = 4;
      int porta = 7;
      String nome = "Evento_4_Porta7";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta8")))    //referente Porta 8
    {
      int evento = 4;
      int porta = 8;
      String nome = "Evento_4_Porta8";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta9")))    //referente Porta 9
    {
      int evento = 4;
      int porta = 9;
      String nome = "Evento_4_Porta9";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta10")))    //referente Porta 10
    {
      int evento = 4;
      int porta = 10;
      String nome = "Evento_4_Porta10";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta11")))    //referente Porta 11
    {
      int evento = 4;
      int porta = 11;
      String nome = "Evento_4_Porta11";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta12")))    //referente Porta 12
    {
      int evento = 4;
      int porta = 12;
      String nome = "Evento_4_Porta12";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    
    
    ////////////////////////////     EVENTO 5       /////////////////////////////////////   
    if(theEvent.isFrom(cp5.getController("evento_5_default")))    //referente evento5 Porta 1
    {
      int evento = 5;
      int porta = 1;
      String nome = "Evento_5_default";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta2")))    //referente Porta 2
    {
      int evento = 5;
      int porta = 2;
      String nome = "Evento_5_Porta2";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta3")))    //referente Porta 3
    {
      int evento = 5;
      int porta = 3;
      String nome = "Evento_5_Porta3";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta4")))    //referente Porta 4
    {
      int evento = 5;
      int porta = 4;
      String nome = "Evento_5_Porta4";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta5")))    //referente Porta 5
    {
      int evento = 5;
      int porta = 5;
      String nome = "Evento_5_Porta5";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta6")))    //referente Porta 6
    {
      int evento = 5;
      int porta = 6;
      String nome = "Evento_5_Porta6";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta7")))    //referente Porta 7
    {
      int evento = 5;
      int porta = 7;
      String nome = "Evento_5_Porta7";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta8")))    //referente Porta 8
    {
      int evento = 5;
      int porta = 8;
      String nome = "Evento_5_Porta8";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta9")))    //referente Porta 9
    {
      int evento = 5;
      int porta = 9;
      String nome = "Evento_5_Porta9";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta10")))    //referente Porta 10
    {
      int evento = 5;
      int porta = 10;
      String nome = "Evento_5_Porta10";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta11")))    //referente Porta 11
    {
      int evento = 5;
      int porta = 11;
      String nome = "Evento_5_Porta11";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }
    
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta12")))    //referente Porta 12
    {
      int evento = 5;
      int porta = 12;
      String nome = "Evento_5_Porta12";
      
      int ID = theEvent.getController().getId();
      float valorMinimo = round( theEvent.getController().getArrayValue(0) );
      float valorMaximo = round( theEvent.getController().getArrayValue(1) );
      setaVetoresEvento(evento, porta, valorMinimo, valorMaximo);
      valoresRangeSlider(nome, valorMinimo, valorMaximo);
      debugInterfaceEventos(evento, porta);
      boolean usando = theEvent.getController().isMousePressed();
      sentinela.dedurar(ID, valorMinimo, valorMaximo, usando);
    }


  ///////////////////////////////////////////////////////////////////////
 // Gerenciando Knobs de tempo Máximo p/ setar tempo máximo de EVENTO //
///////////////////////////////////////////////////////////////////////

  else if(theEvent.isFrom("knobTempoMaximo_default"))
  {
    int ID = theEvent.getController().getId();
    float novoMaximo = round(theEvent.getController().getValue() );
    cp5.getController("evento_1_default").setMax(novoMaximo);
    cp5.getController("evento_2_default").setMax(novoMaximo);
    cp5.getController("evento_3_default").setMax(novoMaximo);
    cp5.getController("evento_4_default").setMax(novoMaximo);
    cp5.getController("evento_5_default").setMax(novoMaximo);
    valorTempoMaximo("valorTempoMaximo_default", novoMaximo);
    boolean usando = theEvent.getController().isMousePressed();
    sentinela.dedurar(ID, 0, novoMaximo, usando);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta2"))
  {
    int ID = theEvent.getController().getId();
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta2").setMax(novoMaximo);
    cp5.getController("evento_2_Porta2").setMax(novoMaximo);
    cp5.getController("evento_3_Porta2").setMax(novoMaximo);
    cp5.getController("evento_4_Porta2").setMax(novoMaximo);
    cp5.getController("evento_5_Porta2").setMax(novoMaximo);
    valorTempoMaximo("valorTempoMaximo_Porta2", novoMaximo);
    boolean usando = theEvent.getController().isMousePressed();
    sentinela.dedurar(ID, 0, novoMaximo, usando);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta3"))
  {
    int ID = theEvent.getController().getId();
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta3").setMax(novoMaximo);
    cp5.getController("evento_2_Porta3").setMax(novoMaximo);
    cp5.getController("evento_3_Porta3").setMax(novoMaximo);
    cp5.getController("evento_4_Porta3").setMax(novoMaximo);
    cp5.getController("evento_5_Porta3").setMax(novoMaximo);
    valorTempoMaximo("valorTempoMaximo_Porta3", novoMaximo);
    boolean usando = theEvent.getController().isMousePressed();
    sentinela.dedurar(ID, 0, novoMaximo, usando);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta4"))
  {
    int ID = theEvent.getController().getId();
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta4").setMax(novoMaximo);
    cp5.getController("evento_2_Porta4").setMax(novoMaximo);
    cp5.getController("evento_3_Porta4").setMax(novoMaximo);
    cp5.getController("evento_4_Porta4").setMax(novoMaximo);
    cp5.getController("evento_5_Porta4").setMax(novoMaximo);
    valorTempoMaximo("valorTempoMaximo_Porta4", novoMaximo);
    boolean usando = theEvent.getController().isMousePressed();
    sentinela.dedurar(ID, 0, novoMaximo, usando);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta5"))
  {
    int ID = theEvent.getController().getId();
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta5").setMax(novoMaximo);
    cp5.getController("evento_2_Porta5").setMax(novoMaximo);
    cp5.getController("evento_3_Porta5").setMax(novoMaximo);
    cp5.getController("evento_4_Porta5").setMax(novoMaximo);
    cp5.getController("evento_5_Porta5").setMax(novoMaximo);
    valorTempoMaximo("valorTempoMaximo_Porta5", novoMaximo);
    boolean usando = theEvent.getController().isMousePressed();
    sentinela.dedurar(ID, 0, novoMaximo, usando);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta6"))
  {
    int ID = theEvent.getController().getId();
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta6").setMax(novoMaximo);
    cp5.getController("evento_2_Porta6").setMax(novoMaximo);
    cp5.getController("evento_3_Porta6").setMax(novoMaximo);
    cp5.getController("evento_4_Porta6").setMax(novoMaximo);
    cp5.getController("evento_5_Porta6").setMax(novoMaximo);
    valorTempoMaximo("valorTempoMaximo_Porta6", novoMaximo);
    boolean usando = theEvent.getController().isMousePressed();
    sentinela.dedurar(ID, 0, novoMaximo, usando);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta7"))
  {
    int ID = theEvent.getController().getId();
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta7").setMax(novoMaximo);
    cp5.getController("evento_2_Porta7").setMax(novoMaximo);
    cp5.getController("evento_3_Porta7").setMax(novoMaximo);
    cp5.getController("evento_4_Porta7").setMax(novoMaximo);
    cp5.getController("evento_5_Porta7").setMax(novoMaximo);
    valorTempoMaximo("valorTempoMaximo_Porta7", novoMaximo);
    boolean usando = theEvent.getController().isMousePressed();
    sentinela.dedurar(ID, 0, novoMaximo, usando);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta8"))
  {
    int ID = theEvent.getController().getId();
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta8").setMax(novoMaximo);
    cp5.getController("evento_2_Porta8").setMax(novoMaximo);
    cp5.getController("evento_3_Porta8").setMax(novoMaximo);
    cp5.getController("evento_4_Porta8").setMax(novoMaximo);
    cp5.getController("evento_5_Porta8").setMax(novoMaximo);
    valorTempoMaximo("valorTempoMaximo_Porta8", novoMaximo);
    boolean usando = theEvent.getController().isMousePressed();
    sentinela.dedurar(ID, 0, novoMaximo, usando);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta9"))
  {
    int ID = theEvent.getController().getId();
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta9").setMax(novoMaximo);
    cp5.getController("evento_2_Porta9").setMax(novoMaximo);
    cp5.getController("evento_3_Porta9").setMax(novoMaximo);
    cp5.getController("evento_4_Porta9").setMax(novoMaximo);
    cp5.getController("evento_5_Porta9").setMax(novoMaximo);
    valorTempoMaximo("valorTempoMaximo_Porta9", novoMaximo);
    boolean usando = theEvent.getController().isMousePressed();
    sentinela.dedurar(ID, 0, novoMaximo, usando);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta10"))
  {
    int ID = theEvent.getController().getId();
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta10").setMax(novoMaximo);
    cp5.getController("evento_2_Porta10").setMax(novoMaximo);
    cp5.getController("evento_3_Porta10").setMax(novoMaximo);
    cp5.getController("evento_4_Porta10").setMax(novoMaximo);
    cp5.getController("evento_5_Porta10").setMax(novoMaximo);
    valorTempoMaximo("valorTempoMaximo_Porta10", novoMaximo);
    boolean usando = theEvent.getController().isMousePressed();
    sentinela.dedurar(ID, 0, novoMaximo, usando);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta11"))
  {
    int ID = theEvent.getController().getId();
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta11").setMax(novoMaximo);
    cp5.getController("evento_2_Porta11").setMax(novoMaximo);
    cp5.getController("evento_3_Porta11").setMax(novoMaximo);
    cp5.getController("evento_4_Porta11").setMax(novoMaximo);
    cp5.getController("evento_5_Porta11").setMax(novoMaximo);
    valorTempoMaximo("valorTempoMaximo_Porta11", novoMaximo);
    boolean usando = theEvent.getController().isMousePressed();
    sentinela.dedurar(ID, 0, novoMaximo, usando);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta12"))
  {
    int ID = theEvent.getController().getId();
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta12").setMax(novoMaximo);
    cp5.getController("evento_2_Porta12").setMax(novoMaximo);
    cp5.getController("evento_3_Porta12").setMax(novoMaximo);
    cp5.getController("evento_4_Porta12").setMax(novoMaximo);
    cp5.getController("evento_5_Porta12").setMax(novoMaximo);
    valorTempoMaximo("valorTempoMaximo_Porta12", novoMaximo);
    boolean usando = theEvent.getController().isMousePressed();
    sentinela.dedurar(ID, 0, novoMaximo, usando);
  }


  /////////////////////////////////////
 //  Gerenciando botões de INICIAR  //
/////////////////////////////////////

  else if(theEvent.isFrom("iniciar_default"))    //responde ao acionar botão INICIAR
  {
    println("Enviando eventos tela Porta 1");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta2"))
  {
    println("Enviando eventos tela Porta 2");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta3"))
  {
    println("Enviando eventos tela Porta 3");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta4"))
  {
    println("Enviando eventos tela Porta 4");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta5"))
  {
    println("Enviando eventos tela Porta 5");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta6"))
  {
    println("Enviando eventos tela Porta 6");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta7"))
  {
    println("Enviando eventos tela Porta 7");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta8"))
  {
    println("Enviando eventos tela Porta 8");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta9"))
  {
    println("Enviando eventos tela Porta 9");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta10"))
  {
    println("Enviando eventos tela Porta 10");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta11"))
  {
    println("Enviando eventos tela Porta 11");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta12"))
  {
    println("Enviando eventos tela Porta 12");
    iniciarOperacao();
  }


  ///////////////////////////////
 //  Gerenciando botões de +  //
///////////////////////////////

  else if(theEvent.isFrom("mais_default"))    //responde ao acionar botão +
  {
    incrementarTempo();
    println("botão + apertado na porta 1");
  }
  else if(theEvent.isFrom("mais_Porta2"))
  {
    incrementarTempo();
  }
  else if(theEvent.isFrom("mais_Porta3"))
  {
    incrementarTempo();
  }
  else if(theEvent.isFrom("mais_Porta4"))
  {
    incrementarTempo();
  }
  else if(theEvent.isFrom("mais_Porta5"))
  {
    incrementarTempo();
  }
  else if(theEvent.isFrom("mais_Porta6"))
  {
    incrementarTempo();
  }
  else if(theEvent.isFrom("mais_Porta7"))
  {
    incrementarTempo();
  }
  else if(theEvent.isFrom("mais_Porta8"))
  {
    incrementarTempo();
  }
  else if(theEvent.isFrom("mais_Porta9"))
  {
    incrementarTempo();
  }
  else if(theEvent.isFrom("mais_Porta10"))
  {
    incrementarTempo();
  }
  else if(theEvent.isFrom("mais_Porta11"))
  {
    incrementarTempo();
  }
  else if(theEvent.isFrom("mais_Porta12"))
  {
    incrementarTempo();
  }




  ///////////////////////////////
 //  Gerenciando botões de -  //
///////////////////////////////

  else if(theEvent.isFrom("menos_default"))    //responde ao acionar botão -
  {
    decrementarTempo();
  }
  else if(theEvent.isFrom("menos_Porta2"))
  {
    decrementarTempo();
  }
  else if(theEvent.isFrom("menos_Porta3"))
  {
    decrementarTempo();
  }
  else if(theEvent.isFrom("menos_Porta4"))
  {
    decrementarTempo();
  }
  else if(theEvent.isFrom("menos_Porta5"))
  {
    decrementarTempo();
  }
  else if(theEvent.isFrom("menos_Porta6"))
  {
    decrementarTempo();
  }
  else if(theEvent.isFrom("menos_Porta7"))
  {
    decrementarTempo();
  }
  else if(theEvent.isFrom("menos_Porta8"))
  {
    decrementarTempo();
  }
  else if(theEvent.isFrom("menos_Porta9"))
  {
    decrementarTempo();
  }
  else if(theEvent.isFrom("menos_Porta10"))
  {
    decrementarTempo();
  }
  else if(theEvent.isFrom("menos_Porta11"))
  {
    decrementarTempo();
  }
  else if(theEvent.isFrom("menos_Porta12"))
  {
    decrementarTempo();
  }
}


// Função que seta os valores máx e min de eventos nos vetores de saída
public void setaVetoresEvento(int evento, int porta, float tempoInicial, float tempoFinal)
{
  switch(evento)
  {
    case 1:
      evento1Min[porta - 1] = tempoInicial;
      evento1Max[porta - 1] = tempoFinal;
      break;
      
    case 2:
      evento2Min[porta - 1] = tempoInicial;
      evento2Max[porta - 1] = tempoFinal;
      break;
      
    case 3:
      evento3Min[porta - 1] = tempoInicial;
      evento3Max[porta - 1] = tempoFinal;
      break;
      
    case 4:
      evento4Min[porta - 1] = tempoInicial;
      evento4Max[porta - 1] = tempoFinal;
      break;
      
    case 5:
      evento5Min[porta - 1] = tempoInicial;
      evento5Max[porta - 1] = tempoFinal;
      break;
  }  
}


// Função de debug para Eventos (interface)
public void debugInterfaceEventos(int evento, int porta)
{
  print("Mínimo e máximo do Evento "); print(evento);
  print(" Porta "); print(porta); print(": ");
  
  switch (evento)
  {
    case 1:
      print(evento1Min[porta - 1]); print(", "); print(evento1Max[porta - 1]); println(")");
      break;
    
    case 2:
      print(evento2Min[porta - 1]); print(", "); print(evento2Max[porta - 1]); println(")");
      break;
    
    case 3:
      print(evento3Min[porta - 1]); print(", "); print(evento3Max[porta - 1]); println(")");
      break;
    
    case 4:
      print(evento4Min[porta - 1]); print(", "); print(evento4Max[porta - 1]); println(")");
      break;
    
    case 5:
      print(evento5Min[porta - 1]); print(", "); print(evento5Max[porta - 1]); println(")");
      break;
  }
}


// Função para setar valores máx e min dos textLabel dos rangeSliders (gambiarra)
public void valoresRangeSlider(String nome, float minimo, float maximo)
{
  String min = str(PApplet.parseInt(minimo));
  String max = str(PApplet.parseInt(maximo));
  
  Textlabel valorMin = cp5.get(Textlabel.class, "min" + nome);
  valorMin.setText(min);
  
  Textlabel valorMax = cp5.get(Textlabel.class, "max" + nome);
  valorMax.setText(max);
}


// Função para setar valor de knob no textLabel de valor (gambiarra)
public void valorTempoMaximo(String nome, float novoValor)
{
  String valor = str(PApplet.parseInt(novoValor));
  Textlabel valorTempoMaximo = cp5.get(Textlabel.class, nome);
  valorTempoMaximo.setText(valor);
}


// função para aumentar em 1 ms o tempo do último rangeSlider ou knob usado
public void incrementarTempo()
{
  int porta = sentinela.dedoDuro_porta();
  String controlador = sentinela.dedoDuro_nome();
  int ID = sentinela.dedoDuro_ID();
  float tempoInicial = sentinela.dedoDuro_tempoInicial();
  float tempoFinal = sentinela.dedoDuro_tempoFinal();
  int evento = sentinela.dedoDuro_evento();
  String tab = sentinela.dedoDuro_tab();
  String nome = "Evento_" + evento + tab;
  

  if ( ID < 1000 )  //se for um rangeSlider
  {    //preciso achar uma maneira de alterar vetores evento1Min[] e evento1Max[] aqui...
    if ( sentinela.dedoDuro_moveuIntervalo() )
    {
      tempoInicial += 1;    //incrementa tempoInicial
      tempoFinal += 1;    //incrementa tempoFinal
      valoresRangeSlider(nome, tempoInicial, tempoFinal);  //seta numeros no rangeSlider
      setaVetoresEvento(evento, porta, tempoInicial, tempoFinal);  //seta vetor de saida
      sentinela.dedurar(ID, tempoInicial, tempoFinal, true);  //atualiza sentinela
      //função de debug
      debug_incrementarTempo(controlador, porta);
    }
    else
    {
      if ( sentinela.dedoDuro_mudouTempoInicial() )
      {
        tempoInicial += 1;
        valoresRangeSlider(nome, tempoInicial, tempoFinal);
        setaVetoresEvento(evento, porta, tempoInicial, tempoFinal);
        sentinela.dedurar(ID, tempoInicial, tempoFinal, true);
        //função de debug
        debug_incrementarTempo(controlador, porta);
      }
      else
      {
        tempoFinal += 1;
        valoresRangeSlider(nome, tempoInicial, tempoFinal);
        setaVetoresEvento(evento, porta, tempoInicial, tempoFinal);
        sentinela.dedurar(ID, tempoInicial, tempoFinal, true);                
        //função de debug
        debug_incrementarTempo(controlador, porta);
      }
    }
  }
  else  //se é um knob
  {
    Knob knobTempoMaximo = cp5.get(Knob.class, controlador);
    tempoFinal += 1;
    sentinela.dedurar(ID, tempoInicial, tempoFinal, true);
    knobTempoMaximo.setValue(tempoFinal);
  }
}


// função para diminuir em 1 ms o tempo do último rangeSlider ou knob usado
public void decrementarTempo()
{
  int porta = sentinela.dedoDuro_porta();
  String controlador = sentinela.dedoDuro_nome();
  int ID = sentinela.dedoDuro_ID();
  float tempoInicial = sentinela.dedoDuro_tempoInicial();
  float tempoFinal = sentinela.dedoDuro_tempoFinal();
  int evento = sentinela.dedoDuro_evento();
  String tab = sentinela.dedoDuro_tab();
  String nome = "Evento_" + evento + tab;
  
  //função de debug
  debug_decrementarTempo(controlador, porta);

  
  if ( ID < 1000 )  //se for um rangeSlider
  {    
    if ( sentinela.dedoDuro_moveuIntervalo() )
    {
      tempoInicial -= 1;
      tempoFinal -= 1;
      valoresRangeSlider(nome, tempoInicial, tempoFinal);
      sentinela.dedurar(ID, tempoInicial, tempoFinal, true);
      setaVetoresEvento(evento, porta, tempoInicial, tempoFinal);
      //função de debug
      debug_decrementarTempo(controlador, porta);
    }
    else
    {
      if ( sentinela.dedoDuro_mudouTempoInicial() )
      {
        tempoInicial -= 1;
        valoresRangeSlider(nome, tempoInicial, tempoFinal);
        sentinela.dedurar(ID, tempoInicial, tempoFinal, true);
        setaVetoresEvento(evento, porta, tempoInicial, tempoFinal);
        //função de debug
        debug_decrementarTempo(controlador, porta);
      }
      else
      {
        tempoFinal -= 1;
        valoresRangeSlider(nome, tempoInicial, tempoFinal);
        sentinela.dedurar(ID, tempoInicial, tempoFinal, true);
        setaVetoresEvento(evento, porta, tempoInicial, tempoFinal);
        //função de debug
        debug_decrementarTempo(controlador, porta);
      }
    }
  }
  else  //se é um knob
  {
    Knob knobTempoMaximo = cp5.get(Knob.class, controlador);
    tempoFinal -= 1;
    sentinela.dedurar(ID, tempoInicial, tempoFinal, true);
    knobTempoMaximo.setValue(tempoFinal);
  }
}


// Função para debugar incrementarTempo()
public void debug_incrementarTempo(String controlador, int porta)
{
  print("Adicionando 1ms em ");
  print(controlador);
  print(" na Porta ");
  println(porta);
}


// Função para debugar decrementarTempo()
public void debug_decrementarTempo(String controlador, int porta)
{
  print("Subtraindo 1ms em ");
  print(controlador);
  print(" na Porta ");
  println(porta);
}


  ////////////////////////////////////
 //  Gerenciando toogle de TENSÃO  //
////////////////////////////////////

public void tensao_default(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 1\n");
  setarTensaoPorta(1, estadoToggle);
}

public void tensao_Porta2(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 2");
  setarTensaoPorta(2, estadoToggle);
}

public void tensao_Porta3(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 3");
  setarTensaoPorta(3, estadoToggle);
}

public void tensao_Porta4(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 4");
  setarTensaoPorta(4, estadoToggle);
}

public void tensao_Porta5(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 5");
  setarTensaoPorta(5, estadoToggle);
}

public void tensao_Porta6(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 6");
  setarTensaoPorta(6, estadoToggle);
}

public void tensao_Porta7(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 7");
  setarTensaoPorta(7, estadoToggle);
}

public void tensao_Porta8(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 8");
  setarTensaoPorta(8, estadoToggle);
}

public void tensao_Porta9(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 9");
  setarTensaoPorta(9, estadoToggle);
}

public void tensao_Porta10(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 10");
  setarTensaoPorta(10, estadoToggle);
}

public void tensao_Porta11(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 11");
  setarTensaoPorta(11, estadoToggle);
}

public void tensao_Porta12(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 12");
  setarTensaoPorta(12, estadoToggle);
}




//===========================================================================================
//  Tempo Máximo - seta o Evento para o tempo máximo determinado pelo knob
//===========================================================================================

public void knobTempoMaximo(int theValue) 
{
  println("a knob event. Value = "+ theValue);
  int novoMax = theValue;
  rangeEvento1.setMax(novoMax);    //esta instrução está retornando um erro no console
}


//===========================================================================================
//  Gerador do elemento de interface Tabs (que seleciona a Porta a ser configurada)
//
//===========================================================================================
public void gerarTabs()
{
  PFont pfont = createFont("Arial",20,true); // use true/false for smooth/no-smooth
  ControlFont font_min = new ControlFont(pfont, 12);
  
  cp5.getTab("default")
     .activateEvent(true)
     .setLabel("     1")
     .setHeight(50)
     .setWidth(50)
     .setId(1)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta2")
     .activateEvent(true)
     .setLabel("     2")
     .setHeight(50)
     .setWidth(50)
     .setId(2)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta3")
     .activateEvent(true)
     .setLabel("     3")
     .setHeight(50)
     .setWidth(50)
     .setId(3)
     .getCaptionLabel()
     .setFont(font_min)
     ;
  
  cp5.addTab("Porta4")
     .activateEvent(true)
     .setLabel("     4")
     .setHeight(50)
     .setWidth(50)
     .setId(4)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta5")
     .activateEvent(true)
     .setLabel("     5")
     .setHeight(50)
     .setWidth(50)
     .setId(5)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta6")
     .activateEvent(true)
     .setLabel("     6")
     .setHeight(50)
     .setWidth(50)
     .setId(6)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta7")
     .activateEvent(true)
     .setLabel("     7")
     .setHeight(50)
     .setWidth(50)
     .setId(7)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta8")
     .activateEvent(true)
     .setLabel("     8")
     .setHeight(50)
     .setWidth(50)
     .setId(8)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta9")
     .activateEvent(true)
     .setLabel("     9")
     .setHeight(50)
     .setWidth(50)
     .setId(9)
     .getCaptionLabel()
     .setFont(font_min)
     ;
  
  cp5.addTab("Porta10")
     .activateEvent(true)
     .setLabel("    10")
     .setHeight(50)
     .setWidth(50)
     .setId(10)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta11")
     .activateEvent(true)
     .setLabel("    11")
     .setHeight(50)
     .setWidth(50)
     .setId(11)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta12")
     .activateEvent(true)
     .setLabel("    12")
     .setHeight(50)
     .setWidth(50)
     .setId(12)
     .getCaptionLabel()
     .setFont(font_min)
     ;
}

//===========================================================================================
//  gerarInterface - gera elementos da Interface para uma Tab
//
//===========================================================================================

public void gerarInterface(String tab, int ID)
{
  int posX = 398;      //posição x do primeiro slider
  int posY = 200;      //posição y do primeiro slider
  int posX_TempoMaximo = 120;
  int poxY_TempoMaximo = 320;

  PFont pfont = createFont("Arial",20,true); // use true/false for smooth/no-smooth
  ControlFont font = new ControlFont(pfont, 20);
  ControlFont font_min = new ControlFont(pfont, 12);
  ControlFont font_med = new ControlFont(pfont, 16);
  
  cp5.addTextlabel("labelSaida" + "_" + tab)
     .setText("PORTAS")
     .setPosition(655, 10)
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;

  cp5.addTextlabel("labelTensao" + "_" + tab)
     .setText("TENSÃO")
     .setPosition( (toogleTensaoPosX + 80) , toogleTensaoPosY )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
  
  cp5.addButton("iniciar" + "_" + tab)
     .setPosition(900,50)
     .setSize(82,82)
     .setLabel("iniciar")
     .setFont(font_med)
     .isPressed()
     ;
  cp5.getController("iniciar" + "_" + tab).moveTo(tab);

  cp5.addButton("menos_" + tab)
     .setPosition(140,240)
     .setSize(55,55)
     .setLabel("-")
     .setFont(font_med)
     .isPressed()
     ;
  cp5.getController("menos_" + tab).moveTo(tab);
  
  cp5.addButton("mais_" + tab)
     .setPosition(210,240)
     .setSize(55,55)
     .setLabel("+")
     .setFont(font_med)
     .isPressed()
     ;
  cp5.getController("mais_" + tab).moveTo(tab);
  
  cp5.addKnob("knobTempoMaximo" + "_" + tab)
     .setBroadcast(false)
     .setDecimalPrecision(0)
     .setRange(0,18000)
     .setValue((int)rangeMax)
     .setPosition(posX_TempoMaximo, poxY_TempoMaximo)
     .setRadius(80)
     .setLabel("Tempo Máximo")
     .setFont(font)
     .setId(1000 + ID)
     .setLabelVisible(false)
     .setBroadcast(true)
     .moveTo(tab)
     ;
  
    cp5.addTextlabel("labelTempoMaximo" + "_" + tab)
     .setText("TEMPO MÁXIMO")
     .setPosition( (posX_TempoMaximo - 8) , (poxY_TempoMaximo + 160) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
  
  cp5.addTextlabel("valorTempoMaximo" + "_" + tab)
     .setText("7000")
     .setPosition( (posX_TempoMaximo + 49) , (poxY_TempoMaximo + 65) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;

  cp5.addToggle("tensao" + "_" + tab)
     .setPosition( toogleTensaoPosX , toogleTensaoPosY )
     .setSize(72, 26)
     .setValue(true)
     .setMode(ControlP5.SWITCH)
     .setLabel(" 12V  -  24V")
     .setFont(font_min)
     .moveTo(tab)
     ;

//// - Range Slider EVENTO 1 - ////
  cp5.addRange("evento_1" + "_" + tab)
     .setBroadcast(false)
     .setDecimalPrecision(0)
     .setPosition(posX, posY)
     .setSize(580, 52)
     .setHandleSize(18)
     .setRange(rangeMin, rangeMax)
     .setRangeValues(rangeMin, rangeMin)
     .setLabel("Evento 1")
     .setFont(font)
     .setId(100 + ID)
     .setLabelVisible(false)
     .setBroadcast(true)
     .moveTo(tab)
     ;
  
  cp5.addTextlabel("nomeEvento_1" + "_" + tab)
     .setText("EVENTO 1")
     .setPosition( (posX + 230) , (posY + 12) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
  
  cp5.addTextlabel("minEvento_1" + "_" + tab)
     .setText("0")
     .setPosition( (posX + 5) , (posY + 12) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
   
   cp5.addTextlabel("maxEvento_1" + "_" + tab)
     .setText("0")
     .setPosition( (posX + 505) , (posY + 12) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;


//// - Range Slider EVENTO 2 - ////
  cp5.addRange("evento_2" + "_" + tab)
     .setBroadcast(false)
     .setDecimalPrecision(0)
     .setPosition(posX, posY+80)
     .setSize(580, 52)
     .setHandleSize(18)
     .setRange(rangeMin, rangeMax)
     .setRangeValues(rangeMin, rangeMin)
     .setLabel("Evento 2")
     .setFont(font)
     .setId(200 + ID)
     .setLabelVisible(false)
     .setBroadcast(true)
     .moveTo(tab)
     ;

  cp5.addTextlabel("nomeEvento_2" + "_" + tab)
     .setText("EVENTO 2")
     .setPosition( (posX + 230) , (posY + 92) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
  
  cp5.addTextlabel("minEvento_2" + "_" + tab)
     .setText("0")
     .setPosition( (posX + 5) , (posY + 92) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
   
   cp5.addTextlabel("maxEvento_2" + "_" + tab)
     .setText("0")
     .setPosition( (posX + 505) , (posY + 92) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;


//// - Range Slider EVENTO 3 - ////
  cp5.addRange("evento_3" + "_" + tab)
     .setBroadcast(false)
     .setDecimalPrecision(0)
     .setPosition(posX, posY+160)
     .setSize(580, 52)
     .setHandleSize(18)
     .setRange(rangeMin, rangeMax)
     .setRangeValues(rangeMin, rangeMin)
     .setLabel("Evento 3")
     .setFont(font)
     .setId(300 + ID)
     .setLabelVisible(false)
     .setBroadcast(true)
     .moveTo(tab)
     ;

  cp5.addTextlabel("nomeEvento_3" + "_" + tab)
     .setText("EVENTO 3")
     .setPosition( (posX + 230) , (posY + 172) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
  
  cp5.addTextlabel("minEvento_3" + "_" + tab)
     .setText("0")
     .setPosition( (posX + 5) , (posY + 172) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
   
   cp5.addTextlabel("maxEvento_3" + "_" + tab)
     .setText("0")
     .setPosition( (posX + 505) , (posY + 172) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;


//// - Range Slider EVENTO 4 - ////
  cp5.addRange("evento_4" + "_" + tab)
     .setBroadcast(false)
     .setDecimalPrecision(0)
     .setPosition(posX, posY+240)
     .setSize(580, 52)
     .setHandleSize(18)
     .setRange(rangeMin, rangeMax)
     .setRangeValues(rangeMin, rangeMin)
     .setLabel("Evento 4")
     .setFont(font)
     .setId(400 + ID)
     .setLabelVisible(false)
     .setBroadcast(true)
     .moveTo(tab)
     ;

  cp5.addTextlabel("nomeEvento_4" + "_" + tab)
     .setText("EVENTO 4")
     .setPosition( (posX + 230) , (posY + 252) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
  
  cp5.addTextlabel("minEvento_4" + "_" + tab)
     .setText("0")
     .setPosition( (posX + 5) , (posY + 252) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
   
   cp5.addTextlabel("maxEvento_4" + "_" + tab)
     .setText("0")
     .setPosition( (posX + 505) , (posY + 252) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;


//// - Range Slider EVENTO 5 - ////
  cp5.addRange("evento_5" + "_" + tab)
     .setBroadcast(false)
     .setDecimalPrecision(0)
     .setPosition(posX, posY+320)
     .setSize(580, 52)
     .setHandleSize(18)
     .setRange(rangeMin, rangeMax)
     .setRangeValues(rangeMin, rangeMin)
     .setLabel("Evento 5")
     .setFont(font)
     .setId(500 + ID)
     .setLabelVisible(false)
     .setBroadcast(true)
     .moveTo(tab)
     ;

  cp5.addTextlabel("nomeEvento_5" + "_" + tab)
     .setText("EVENTO 5")
     .setPosition( (posX + 230) , (posY + 332) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
  
  cp5.addTextlabel("minEvento_5" + "_" + tab)
     .setText("0")
     .setPosition( (posX + 5) , (posY + 332) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
   
   cp5.addTextlabel("maxEvento_5" + "_" + tab)
     .setText("0")
     .setPosition( (posX + 505) , (posY + 332) )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
}


//===========================================================================================
/*                  --------------  Fim do Programa  --------------                        */
//===========================================================================================
//===========================================================================================
//  Sentinela - Classe que armazena e retorna valores do ID, dos tempos e o nome do último 
//              "range slider" ou "knob de tempo máximo" modificado.
//
//    objetivo: implementação de um ajuste fino para precisão de 1 ms via interface
//
//===========================================================================================


class Sentinela
{
  //Declaração dos campos da classe Sentinela
  boolean modificouPorta = false;  //se Porta (Tab) sofreu modificação
  int portaObjeto = 0;    //armazena Porta do último elemento de interface modificado
  int evento = 0;    //armazena o Evento modificado se existir
  
  boolean modificouObjetoID = false;  //se objetoID sofreu modificação
  int objetoID = 0;    //armazena o último elemento de interface modificado
  
  boolean modificouTempoInicial = false; //se tempoInicial foi alteração
  float memoriaTempoInicial = 0;    //variavel para armazenar último valor modificado
                                    // do tempo inicial de qualquer range slider de 
                                    // eventos da interface
  
  boolean modificouTempoFinal = false; //se tempoFinal sofreu alteração
  float memoriaTempoFinal = 0;    //variavel para armazenar último valor modificado
                                  // do tempo final de qualquer range slider de
                                  // eventos da interface ou do knon TEMPO MÁXIMO

  boolean moveuIntervalo = false;    //se algum range slider teve o tempo inicial e final
                                     // modificados simultaneamente


  String objeto = "";    //recebe o nome do objeto modificado (rangeSlider ou knob)


  //nomes (label) dos rangeSliders dos Eventos da Normae na interface gráfica
  String[][] rangeSlider = { 
    {"evento_1_default", "evento_2_default", "evento_3_default",
                 "evento_4_default", "evento_5_default"},
    {"evento_1_Porta2", "evento_2_Porta2", "evento_3_Porta2",
                 "evento_4_Porta2", "evento_5_Porta2"},
    {"evento_1_Porta3", "evento_2_Porta3", "evento_3_Porta3", 
                 "evento_4_Porta3", "evento_5_Porta3"},
    {"evento_1_Porta4", "evento_2_Porta4", "evento_3_Porta4",
                 "evento_4_Porta4", "evento_5_Porta4"},
    {"evento_1_Porta5", "evento_2_Porta5", "evento_3_Porta5",
                 "evento_4_Porta5", "evento_5_Porta5"},
    {"evento_1_Porta6", "evento_2_Porta6", "evento_3_Porta6", 
                 "evento_4_Porta6", "evento_5_Porta6"},
    {"evento_1_Porta7", "evento_2_Porta7", "evento_3_Porta7",
                 "evento_4_Porta7", "evento_5_Porta7"},
    {"evento_1_Porta8", "evento_2_Porta8", "evento_3_Porta8", 
                 "evento_4_Porta8", "evento_5_Porta8"},
    {"evento_1_Porta9", "evento_2_Porta9", "evento_3_Porta9",
                 "evento_4_Porta9", "evento_5_Porta9"},
    {"evento_1_Porta10", "evento_2_Porta10", "evento_3_Porta10",
                 "evento_4_Porta10", "evento_5_Porta10"},
    {"evento_1_Porta11", "evento_2_Porta11", "evento_3_Porta11",
                 "evento_4_Porta11", "evento_5_Porta11"},
    {"evento_1_Porta12", "evento_2_Porta12", "evento_3_Porta12",
                 "evento_4_Porta12", "evento_5_Porta12"}
  };

  //nomes (label) dos knobs Tempo Máximo na interface gráfica da Normae
  String[] knob = {"knobTempoMaximo_default", "knobTempoMaximo_Porta2",
                   "knobTempoMaximo_Porta3", "knobTempoMaximo_Porta4",
                   "knobTempoMaximo_Porta5", "knobTempoMaximo_Porta6", 
                   "knobTempoMaximo_Porta7", "knobTempoMaximo_Porta8",
                   "knobTempoMaximo_Porta9", "knobTempoMaximo_Porta10",
                   "knobTempoMaximo_Porta11", "knobTempoMaximo_Porta12" };

  String[] tab = {"_default", "_Porta2", "_Porta3", "_Porta4",
                  "_Porta5", "_Porta6", "_Porta7", "_Porta8",
                  "_Porta9", "_Porta10", "_Porta11", "_Porta12"}; 
  
 //Criação do construtor da classe Sentinela
 Sentinela(int ID, float tempoInicial, float tempoFinal)
 {
   objetoID = ID;
   memoriaTempoInicial = tempoInicial;
   memoriaTempoFinal = tempoFinal;
 }

 //////////////////////////////
 //Métodos da classe Sentinela

 public void dedurar(int ID, float tempoInicial, float tempoFinal, boolean mousePressed)
 {
    if (mousePressed == true)
    {
     float memoria = 0;  //variável para verificar se houve modificação de tempo em algum campo
     int memo = 0;
     
     // modifica o ID do objeto e assinala se houve alteração de valor
     memo = objetoID;
     objetoID = ID;
     if (memo != objetoID){ modificouObjetoID = true; }
     else { modificouObjetoID = false; }
     
     // modifica a Porta (tab) do objeto e assinala se houve alteração de valor
     memoria = portaObjeto;
     setaPortaObjeto();
     if (memoria != portaObjeto){ modificouPorta = true; }
     else { modificouPorta = false; }
     
     // modifica e tempoInicial e assinala se houve alteração de valor
     memoria = memoriaTempoInicial;
     memoriaTempoInicial = tempoInicial;
     if (memoria != memoriaTempoInicial) { modificouTempoInicial = true; }
     else { modificouTempoInicial = false; }
     
     // modifica e tempoFinal e assinala se houve alteração de valor
     memoria = memoriaTempoFinal;
     memoriaTempoFinal = tempoFinal;
     if (memoria != memoriaTempoFinal) { modificouTempoFinal = true; }
     else { modificouTempoFinal = false; }
     
     //seta variavel moveuIntervalo
     moveuIntervalo();
     
     // seta evento se for rangeSlider
     setaEvento();
     
     // seta nome do objeto
     setaNomeObjeto();
     
     debug();
    }
 }


 public String dedoDuro_nome()  //retorna String do nome do elemento de inteface modificado
 {
   return objeto;
 }


 public int dedoDuro_ID()  //retorna ID do objeto armazenado
 {
   return objetoID;
 }


 public int dedoDuro_porta()  //retorna numero da porta do objeto armazenado
 {
   return portaObjeto;
 }


 public String dedoDuro_tab()  //retorna página (porta) do objeto armazenado
 {
   return tab[portaObjeto - 1];
 }


 public int dedoDuro_evento()  //retorna evento do objeto armazenado (!= 0 se existir)
 {
   return evento;
 }


 public float dedoDuro_tempoInicial()  //retorna float com tempo Inicial do elemento armazenado
 {
   return memoriaTempoInicial;
 }


 public boolean dedoDuro_mudouTempoInicial() //retorna se tempo Inicial foi modificado
 {
   return modificouTempoInicial;
 }


 public float dedoDuro_tempoFinal()  //retorna float com tempo Final do elemento armazenado
 {
   return memoriaTempoFinal;
 }


 public boolean dedoDuro_mudouTempoFinal() //retorna se tempo Final foi modificado
 {
   return modificouTempoFinal;
 }  


 public boolean dedoDuro_moveuIntervalo()  //retorna de intervalo de rangeSlider foi modificado
 {
   return moveuIntervalo;
 }


  //////////////////////////////////////
 // métodos para setar campos da classe 
 
  public void setaObjeto()    // seta nome do objeto a partir do ID
  {
    
    if (objetoID >= 1000)
    {
      portaObjeto = PApplet.parseInt(objetoID % 1000);
      evento = 0;
      objeto = knob[portaObjeto - 1];
    }
    else
    {
      if(objetoID > 100)
      {
        portaObjeto = PApplet.parseInt(objetoID % 100);
        evento = PApplet.parseInt(objetoID / 100);
        objeto = rangeSlider[portaObjeto - 1][evento - 1];
      }
    }
  }


  public void setaEvento()    // seta nome do objeto a partir do ID
  {
    
    if (objetoID >= 1000)
    { evento = 0; }
    else
    { if(objetoID > 100)
      { evento = PApplet.parseInt(objetoID / 100); }
    }
  }


  public void setaPortaObjeto()    // seta Porta do objeto
  { 
    if (objetoID >= 1000)  //se for knob
    { portaObjeto = PApplet.parseInt(objetoID % 1000); }
    else
    { if(objetoID > 100)  //se é rangeSlider
      { portaObjeto = PApplet.parseInt(objetoID % 100); }
    }
  }


  public void setaNomeObjeto()    // seta nome do objeto
  { 
    if (objetoID >= 1000)
    { objeto = knob[portaObjeto - 1]; }
    else
    { if(objetoID > 100)
      { objeto = rangeSlider[portaObjeto - 1][evento - 1]; }
    }
  }
 
 
 public void moveuIntervalo()  //retorna se o intervalo do Range Slider foi realocado
 {
   if (objetoID < 1000)    //se o elemento modificado é um Range Slider
   {
     //se o tempoInicial e o tempoFinal sofreram alteração
     if (modificouTempoInicial == true && modificouTempoFinal == true)
     { moveuIntervalo = true; }    //o intervalo foi movido
     else { moveuIntervalo = false; }  // o intervalo não foi movido
   }
   else { moveuIntervalo = false; }  //senão não :P
 }


 public void debug()
 {
   print("O elemento de interface está na Porta: "); println(portaObjeto);
   print("O label do elemento de interface = "); println(objeto);
   print("ID do elemento modificado = "); println(objetoID);
   print("O tempo inicial foi modificado? "); println(modificouTempoInicial);
   print("O tempo final foi modificado? "); println(modificouTempoFinal);
   print("O intervalo foi movido? "); println(moveuIntervalo);
   print("tempoInicial guardado em sentinela: "); println(memoriaTempoInicial);
   print("tempoFinal guardado em sentinela: "); println(memoriaTempoFinal);
   println();
 }
}
  public void settings() {  size(1024,600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#013764", "--hide-stop", "normaeProtoInterface_01_Shiyozi" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
