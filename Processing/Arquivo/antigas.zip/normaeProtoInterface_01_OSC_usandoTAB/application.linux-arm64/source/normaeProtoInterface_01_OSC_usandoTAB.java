import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 
import netP5.*; 
import oscP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class normaeProtoInterface_01_OSC_usandoTAB extends PApplet {

/********************************************************************************************
 * Protótipo de Interface para Normae_12 - Shiyozi
 * Interface de 1 range slider com seletor de porta para acionamento
 * e desacionamento de módulo de relé
 *
 *******************************************************************************************/

/* ToDo
 *  - Criar Suporte a 7 Eventos na interface
 *
 *  - Solução para incrementar e decrementar unidade por unidade na interface
 *
 */

//===========================================================================================
//                            Declaração de Bibliotecas
//===========================================================================================

//import gohai.simpletouch.*;    //biblioteca de entradas multi-touch
            //biblioteca de eLementos da interface
                //dependência para oscP5
                //biblioteca de protocolo OSC


//===========================================================================================
//                            Inicialização de objetos
//===========================================================================================

OscP5 oscP5;    //referente a biblioteca para comunicação OSC
NetAddress enderecoNormae;    //para inicialização de endereço de rede da controladora Normae
NetAddress enderecoMac;    //para inicialização de endereço de rede do computador para debug

ControlP5 cp5;    //referente a biblioteca controlP5

Textlabel tituloPortas;    //texto com título do seletor de porta de saída

Textlabel tituloTensao;    //texto com título do seletor de tensão da porta selecionada

Textlabel indicePortas;    //texto com o número de cada porta para seletor de portas de saída

RadioButton portas;    //objeto gráfico de seleção de porta de saída

Numberbox inTempoMaximo;     //objeto gráfico de entrada de tempo máximo
Knob knobTempoMaximo;    //objeto gráfico de entrada de tempo máximo

Range rangeEvento1;    //objeto gráfico de entrada de tempo inicial e final de cada evento


//===========================================================================================
//                               Variáveis Globais
//===========================================================================================

int myColorBackground = 100;    //cor de fundo da tela de interface gráfica

boolean[] toggleValue = new boolean[12];    //seletor de tensão da porta (12V-24V)

float[] evento1Min = new float[12]; float[] evento2Min = new float[12];
float[] evento3Min = new float[12]; float[] evento4Min = new float[12];
float[] evento5Min = new float[12]; float[] evento6Min = new float[12];
float[] evento7Min = new float[12];

float[] evento1Max = new float[12]; float[] evento2Max = new float[12];
float[] evento3Max = new float[12]; float[] evento4Max = new float[12];
float[] evento5Max = new float[12]; float[] evento6Max = new float[12];
float[] evento7Max = new float[12];

float tempoTotal;

float rangeMin = 0.0f;    //valor mínimo de cada slider
float rangeMax = 7000.00f;    //valor máximo de cada slider
int posX = 390;      //posição x do primeiro slider
int posY = 200;      //posição y do primeiro slider

int porta1 = 0, porta2 = 0, porta3 = 0, porta4 = 0,    //contém o estado do botões
    porta5 = 0, porta6 = 0, porta7 = 0, porta8 = 0,    //das  Portas de Saída.
    porta9 = 0, porta10 = 0, porta11 = 0, porta12 = 0;
int portaAtiva;
int toogleTensaoPosX = 60;    //posição X da interface de seleção de Porta de Saída
int toogleTensaoPosY = 95;    //posição Y da interface de seleção de Porta de Saída


//===========================================================================================
//                       Configuração da Interface (Geração)
//===========================================================================================
public void setup()
{
  
  noStroke();

  oscP5 = new OscP5(this,7777);    //ouvindo na porta 7777
  enderecoNormae = new NetAddress("169.254.81.77",5555);//endereço comunicação LAN com Normae
  enderecoMac =  new NetAddress("192.168.0.255",5555);//endereço p teste mac
  
  cp5 = new ControlP5(this);

  gerarTabs();
 
  gerarInterface("default");
  gerarInterface("Porta2");
  gerarInterface("Porta3");
  gerarInterface("Porta4");
  gerarInterface("Porta5");
  gerarInterface("Porta6");
  gerarInterface("Porta7");
  gerarInterface("Porta8");
  gerarInterface("Porta9");
  gerarInterface("Porta10");
  gerarInterface("Porta11");
  gerarInterface("Porta12");
   
}


//===========================================================================================
//                                   Programa
//===========================================================================================
public void draw()
{
  background(60);
}


//===========================================================================================
//                           Construção de mensagens OSC
//===========================================================================================

  //////////////////////////////////////////////////////////////////////////////////////
 /// Envia vetores de tempo mínimo e máximo de EVENTOS e INÍCIO da operação por OSC ///
//////////////////////////////////////////////////////////////////////////////////////

//msg: /setar/evento/int(numeroDoEvento)/Porta/int(numeroDaPorta)/
//      tempoInicio/String(tempoInicio)/tempoFinal/String(tempoFinal)

public void setarEventos()    // mensagens p/ setar Evento em todas as Portas
{
  setarTempoTotal_e_AtivacaoDeEventos();
  
  String tempoInicio;
  String tempoFinal;
  
    for ( int numeroDoEvento = 1; numeroDoEvento <= 7; numeroDoEvento++)
    {
      for ( int i = 0; i <= 11; i++)
      {
      OscMessage setandoEvento = new OscMessage("/setar/evento");
      setandoEvento.add(numeroDoEvento);
      setandoEvento.add("Porta");
      setandoEvento.add(i + 1);                   // porta a ser setada
        switch(numeroDoEvento)
        {
          case 1:
          setandoEvento.add("tempoInicio");
          tempoInicio = str(evento1Min[i]);   // tempo de inicio do evento
          setandoEvento.add(tempoInicio);
          setandoEvento.add("tempoFinal");
          tempoFinal = str(evento1Max[i]);    // tempo final do evento
          setandoEvento.add(tempoFinal);
          break;
          
        case 2:
          setandoEvento.add("tempoInicio");
          tempoInicio = str(evento2Min[i]);
          setandoEvento.add(tempoInicio);
          setandoEvento.add("tempoFinal");
          tempoFinal = str(evento2Max[i]);
          setandoEvento.add(tempoFinal);
          break;
          
        case 3:
          setandoEvento.add("tempoInicio");
          tempoInicio = str(evento3Min[i]);
          setandoEvento.add(tempoInicio);
          setandoEvento.add("tempoFinal");
          tempoFinal = str(evento3Max[i]);
          setandoEvento.add(tempoFinal);
          break;
          
        case 4:
          setandoEvento.add("tempoInicio");
          tempoInicio = str(evento4Min[i]);
          setandoEvento.add(tempoInicio);
          setandoEvento.add("tempoFinal");
          tempoFinal = str(evento4Max[i]);
          setandoEvento.add(tempoFinal);
          break;
          
        case 5:
          setandoEvento.add("tempoInicio");
          tempoInicio = str(evento5Min[i]);
          setandoEvento.add(tempoInicio);
          setandoEvento.add("tempoFinal");
          tempoFinal = str(evento5Max[i]);
          setandoEvento.add(tempoFinal);
          break;
          
        case 6:
          setandoEvento.add("tempoInicio");
          tempoInicio = str(evento6Min[i]);
          setandoEvento.add(tempoInicio);
          setandoEvento.add("tempoFinal");
          tempoFinal = str(evento6Max[i]);
          setandoEvento.add(tempoFinal);
            break;
            
        case 7:
          setandoEvento.add("tempoInicio");
          tempoInicio = str(evento7Min[i]);
          setandoEvento.add(tempoInicio);
          setandoEvento.add("tempoFinal");
          tempoFinal = str(evento7Max[i]);
          setandoEvento.add(tempoFinal);
          break;
        } 
      oscP5.send(setandoEvento, enderecoNormae);
      oscP5.send(setandoEvento, enderecoMac);
      delay(20);
      }
    }
}


  ///////////////////////////////////////////////////////////////////////////
 /// Envia dado de tempo total e ativação de Eventos da operação por OSC ///
///////////////////////////////////////////////////////////////////////////

//msg: /setar/tempoTotal/String(tempoTotal)

public void setarTempoTotal_e_AtivacaoDeEventos()    // mensagens p/ setar tempoTotal
{                                             //  e Ativação de Eventos
  String tempoMaximo;
  float[] maximoMesmo = new float[7];
  
  OscMessage setandoTempoTotal = new OscMessage("/setar/tempoTotal");
  maximoMesmo[0] = max(evento1Max);
  maximoMesmo[1] = max(evento2Max);
  maximoMesmo[2] = max(evento3Max);
  maximoMesmo[3] = max(evento4Max);
  maximoMesmo[4] = max(evento5Max);
  maximoMesmo[5] = max(evento6Max);
  maximoMesmo[6] = max(evento7Max);
  tempoTotal = max(maximoMesmo);
  tempoMaximo = str(tempoTotal);
  
  setandoTempoTotal.add(tempoMaximo);
  oscP5.send(setandoTempoTotal, enderecoNormae);
  oscP5.send(setandoTempoTotal, enderecoMac);
  
  for ( int i = 0; i <= 6; i++)
  {
    OscMessage setandoEventos = new OscMessage("/setar/modoAtivo");
    if ( maximoMesmo[i] == 0)
    {
      setandoEventos.add(0);
    }
    else
    {
      setandoEventos.add(1);
    }
    setandoEventos.add("evento");
    setandoEventos.add(i + 1);
    oscP5.send(setandoEventos, enderecoNormae);
    oscP5.send(setandoEventos, enderecoMac);
  }
}


  /////////////////////////////////////////////////////////////
 /// Envia mensagem de Iniciar Operação via OSC ///
/////////////////////////////////////////////////////////////

//msg: /iniciar/int(1 para começar)

public void iniciarOperacao()
{
  setarEventos();    //manda OSC bundle com todas as mensagens para setar os Eventos  
  OscMessage iniciarOperacao = new OscMessage("/iniciar");
  iniciarOperacao.add(1);
  oscP5.send(iniciarOperacao, enderecoNormae);
  oscP5.send(iniciarOperacao, enderecoMac);
}


  /////////////////////////////////////////////////////////////
 /// Envia controle de tensão dos Reles nas Portas via OSC ///
/////////////////////////////////////////////////////////////

//msg: /setar/tensao/Porta/(int (1-12))/para/(boolean (true/false))

public void setarTensaoPorta(int numeroDaPorta, boolean estadoDoToggle)
{
  OscMessage setarTensao = new OscMessage("/setar/tensao");
  if( estadoDoToggle == true)
  {
    print("Enviando mensagem com Porta = " + numeroDaPorta + ", toggle = " + estadoDoToggle);
    print("\n");
    setarTensao.add("Porta");
    setarTensao.add(numeroDaPorta);
    setarTensao.add("para");
    setarTensao.add(12);
    oscP5.send(setarTensao, enderecoNormae);
    oscP5.send(setarTensao, enderecoMac);
  }
  else if ( estadoDoToggle == false )
  {
    print("Enviando mensagem com Porta = " + numeroDaPorta + ", toggle = " + estadoDoToggle);
    print("\n");
    setarTensao.add("Porta");
    setarTensao.add(numeroDaPorta);
    setarTensao.add("para");
    setarTensao.add(24);
    oscP5.send(setarTensao, enderecoNormae);
    oscP5.send(setarTensao, enderecoMac);
  }
}


//===========================================================================================
//                           Recebimento de mensagens OSC
//===========================================================================================

/* incoming osc message are forwarded to the oscEvent method. */
public void oscEvent(OscMessage theOscMessage)
{
  /* print the address pattern and the typetag of the received OscMessage */
  print( "### received an osc message." );
  print( " addrpattern: "+theOscMessage.addrPattern() );
  print( "/"+theOscMessage.get(0).intValue() );
  println( " typetag: "+theOscMessage.typetag() );
}


//===========================================================================================
//               Controle de Eventos dos Elementos da Interface
//===========================================================================================

public void controlEvent(ControlEvent theEvent)
{
  //////////////////////////////////////////
 // Gerenciando Range Sliders de EVENTOS //
//////////////////////////////////////////

  if(theEvent.isFrom(cp5.getController("evento_1_default")))    //referente evento1 Porta 1
    {
      evento1Min[0] = theEvent.getController().getArrayValue(0);
      evento1Max[0] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 1: (");
      print(evento1Min[0]); print(", "); print(evento1Max[0]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta2")))    //referente Porta 2
    {
      evento1Min[1] = theEvent.getController().getArrayValue(0);
      evento1Max[1] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 2: (");
      print(evento1Min[1]); print(", "); print(evento1Max[1]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta3")))    //referente Porta 3
    {
      evento1Min[2] = theEvent.getController().getArrayValue(0);
      evento1Max[2] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 3: (");
      print(evento1Min[2]); print(", "); print(evento1Max[2]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta4")))    //referente Porta 4
    {
      evento1Min[3] = theEvent.getController().getArrayValue(0);
      evento1Max[3] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 4: (");
      print(evento1Min[3]); print(", "); print(evento1Max[3]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta5")))    //referente Porta 5
    {
      evento1Min[4] = theEvent.getController().getArrayValue(0);
      evento1Max[4] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 5: (");
      print(evento1Min[4]); print(", "); print(evento1Max[4]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta6")))    //referente Porta 6
    {
      evento1Min[5] = theEvent.getController().getArrayValue(0);
      evento1Max[5] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 6: (");
      print(evento1Min[5]); print(", "); print(evento1Max[5]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta7")))    //referente Porta 7
    {
      evento1Min[6] = theEvent.getController().getArrayValue(0);
      evento1Max[6] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 7: (");
      print(evento1Min[6]); print(", "); print(evento1Max[6]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta8")))    //referente Porta 8
    {
      evento1Min[7] = theEvent.getController().getArrayValue(0);
      evento1Max[7] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 8: (");
      print(evento1Min[7]); print(", "); print(evento1Max[7]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta9")))    //referente Porta 9
    {
      evento1Min[8] = theEvent.getController().getArrayValue(0);
      evento1Max[8] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 9: (");
      print(evento1Min[8]); print(", "); print(evento1Max[8]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta10")))    //referente Porta 10
    {
      evento1Min[9] = theEvent.getController().getArrayValue(0);
      evento1Max[9] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 10: (");
      print(evento1Min[9]); print(", "); print(evento1Max[9]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta11")))    //referente Porta 11
    {
      evento1Min[10] = theEvent.getController().getArrayValue(0);
      evento1Max[10] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 11: (");
      print(evento1Min[10]); print(", "); print(evento1Max[10]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_1_Porta12")))    //referente Porta 12
    {
      evento1Min[11] = theEvent.getController().getArrayValue(0);
      evento1Max[11] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 12: (");
      print(evento1Min[11]); print(", "); print(evento1Max[11]); println(")");
    }
    
   ////////////////////////////     EVENTO 2       /////////////////////////////////////   
    if(theEvent.isFrom(cp5.getController("evento_2_default")))    //referente evento2 Porta 1
    {
      evento2Min[0] = theEvent.getController().getArrayValue(0);
      evento2Max[0] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 1: (");
      print(evento2Min[0]); print(", "); print(evento2Max[0]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta2")))    //referente Porta 2
    {
      evento2Min[1] = theEvent.getController().getArrayValue(0);
      evento2Max[1] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 2: (");
      print(evento2Min[1]); print(", "); print(evento2Max[1]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta3")))    //referente Porta 3
    {
      evento2Min[2] = theEvent.getController().getArrayValue(0);
      evento2Max[2] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 3: (");
      print(evento2Min[2]); print(", "); print(evento2Max[2]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta4")))    //referente Porta 4
    {
      evento2Min[3] = theEvent.getController().getArrayValue(0);
      evento2Max[3] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 4: (");
      print(evento2Min[3]); print(", "); print(evento2Max[3]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta5")))    //referente Porta 5
    {
      evento2Min[4] = theEvent.getController().getArrayValue(0);
      evento2Max[4] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 5: (");
      print(evento2Min[4]); print(", "); print(evento2Max[4]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta6")))    //referente Porta 6
    {
      evento2Min[5] = theEvent.getController().getArrayValue(0);
      evento2Max[5] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 6: (");
      print(evento2Min[5]); print(", "); print(evento2Max[5]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta7")))    //referente Porta 7
    {
      evento2Min[6] = theEvent.getController().getArrayValue(0);
      evento2Max[6] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 7: (");
      print(evento2Min[6]); print(", "); print(evento2Max[6]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta8")))    //referente Porta 8
    {
      evento2Min[7] = theEvent.getController().getArrayValue(0);
      evento2Max[7] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 8: (");
      print(evento2Min[7]); print(", "); print(evento2Max[7]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta9")))    //referente Porta 9
    {
      evento2Min[8] = theEvent.getController().getArrayValue(0);
      evento2Max[8] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 9: (");
      print(evento2Min[8]); print(", "); print(evento2Max[8]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta10")))    //referente Porta 10
    {
      evento2Min[9] = theEvent.getController().getArrayValue(0);
      evento2Max[9] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 10: (");
      print(evento2Min[9]); print(", "); print(evento2Max[9]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta11")))    //referente Porta 11
    {
      evento2Min[10] = theEvent.getController().getArrayValue(0);
      evento2Max[10] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 11: (");
      print(evento2Min[10]); print(", "); print(evento2Max[10]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_2_Porta12")))    //referente Porta 12
    {
      evento2Min[11] = theEvent.getController().getArrayValue(0);
      evento2Max[11] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 12: (");
      print(evento2Min[11]); print(", "); print(evento2Max[11]); println(")");
    }
    
   ////////////////////////////     EVENTO 3       /////////////////////////////////////       
    if(theEvent.isFrom(cp5.getController("evento_3_default")))    //referente evento3 Porta 1
    {
      evento3Min[0] = theEvent.getController().getArrayValue(0);
      evento3Max[0] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 1: (");
      print(evento3Min[0]); print(", "); print(evento3Max[0]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta2")))    //referente Porta 2
    {
      evento3Min[1] = theEvent.getController().getArrayValue(0);
      evento3Max[1] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 2: (");
      print(evento3Min[1]); print(", "); print(evento3Max[1]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta3")))    //referente Porta 3
    {
      evento3Min[2] = theEvent.getController().getArrayValue(0);
      evento3Max[2] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 3: (");
      print(evento3Min[2]); print(", "); print(evento3Max[2]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta4")))    //referente Porta 4
    {
      evento3Min[3] = theEvent.getController().getArrayValue(0);
      evento3Max[3] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 4: (");
      print(evento3Min[3]); print(", "); print(evento3Max[3]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta5")))    //referente Porta 5
    {
      evento3Min[4] = theEvent.getController().getArrayValue(0);
      evento3Max[4] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 5: (");
      print(evento3Min[4]); print(", "); print(evento3Max[4]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta6")))    //referente Porta 6
    {
      evento3Min[5] = theEvent.getController().getArrayValue(0);
      evento3Max[5] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 6: (");
      print(evento3Min[5]); print(", "); print(evento3Max[5]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta7")))    //referente Porta 7
    {
      evento3Min[6] = theEvent.getController().getArrayValue(0);
      evento3Max[6] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 7: (");
      print(evento3Min[6]); print(", "); print(evento3Max[6]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta8")))    //referente Porta 8
    {
      evento3Min[7] = theEvent.getController().getArrayValue(0);
      evento3Max[7] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 8: (");
      print(evento3Min[7]); print(", "); print(evento3Max[7]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta9")))    //referente Porta 9
    {
      evento3Min[8] = theEvent.getController().getArrayValue(0);
      evento3Max[8] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 9: (");
      print(evento3Min[8]); print(", "); print(evento3Max[8]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta10")))    //referente Porta 10
    {
      evento3Min[9] = theEvent.getController().getArrayValue(0);
      evento3Max[9] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 10: (");
      print(evento3Min[9]); print(", "); print(evento3Max[9]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta11")))    //referente Porta 11
    {
      evento3Min[10] = theEvent.getController().getArrayValue(0);
      evento3Max[10] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 11: (");
      print(evento3Min[10]); print(", "); print(evento3Max[10]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_3_Porta12")))    //referente Porta 12
    {
      evento3Min[11] = theEvent.getController().getArrayValue(0);
      evento3Max[11] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 12: (");
      print(evento3Min[11]); print(", "); print(evento3Max[11]); println(")");
    }
    
    ////////////////////////////     EVENTO 4       /////////////////////////////////////       
    if(theEvent.isFrom(cp5.getController("evento_4_default")))    //referente evento4 Porta 1
    {
      evento4Min[0] = theEvent.getController().getArrayValue(0);
      evento4Max[0] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 1: (");
      print(evento4Min[0]); print(", "); print(evento4Max[0]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta2")))    //referente Porta 2
    {
      evento4Min[1] = theEvent.getController().getArrayValue(0);
      evento4Max[1] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 2: (");
      print(evento4Min[1]); print(", "); print(evento4Max[1]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta3")))    //referente Porta 3
    {
      evento4Min[2] = theEvent.getController().getArrayValue(0);
      evento4Max[2] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 3: (");
      print(evento4Min[2]); print(", "); print(evento4Max[2]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta4")))    //referente Porta 4
    {
      evento4Min[3] = theEvent.getController().getArrayValue(0);
      evento4Max[3] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 4: (");
      print(evento4Min[3]); print(", "); print(evento4Max[3]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta5")))    //referente Porta 5
    {
      evento4Min[4] = theEvent.getController().getArrayValue(0);
      evento4Max[4] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 5: (");
      print(evento4Min[4]); print(", "); print(evento4Max[4]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta6")))    //referente Porta 6
    {
      evento4Min[5] = theEvent.getController().getArrayValue(0);
      evento4Max[5] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 6: (");
      print(evento4Min[5]); print(", "); print(evento4Max[5]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta7")))    //referente Porta 7
    {
      evento4Min[6] = theEvent.getController().getArrayValue(0);
      evento4Max[6] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 7: (");
      print(evento4Min[6]); print(", "); print(evento4Max[6]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta8")))    //referente Porta 8
    {
      evento4Min[7] = theEvent.getController().getArrayValue(0);
      evento4Max[7] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 8: (");
      print(evento4Min[7]); print(", "); print(evento4Max[7]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta9")))    //referente Porta 9
    {
      evento4Min[8] = theEvent.getController().getArrayValue(0);
      evento4Max[8] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 9: (");
      print(evento4Min[8]); print(", "); print(evento4Max[8]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta10")))    //referente Porta 10
    {
      evento4Min[9] = theEvent.getController().getArrayValue(0);
      evento4Max[9] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 10: (");
      print(evento4Min[9]); print(", "); print(evento4Max[9]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta11")))    //referente Porta 11
    {
      evento4Min[10] = theEvent.getController().getArrayValue(0);
      evento4Max[10] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 11: (");
      print(evento4Min[10]); print(", "); print(evento4Max[10]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_4_Porta12")))    //referente Porta 12
    {
      evento4Min[11] = theEvent.getController().getArrayValue(0);
      evento4Max[11] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 12: (");
      print(evento4Min[11]); print(", "); print(evento4Max[11]); println(")");
    }
    
    
    ////////////////////////////     EVENTO 5       /////////////////////////////////////       
    if(theEvent.isFrom(cp5.getController("evento_5_default")))    //referente evento5 Porta 1
    {
      evento5Min[0] = theEvent.getController().getArrayValue(0);
      evento5Max[0] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 1: (");
      print(evento5Min[0]); print(", "); print(evento5Max[0]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta2")))    //referente Porta 2
    {
      evento5Min[1] = theEvent.getController().getArrayValue(0);
      evento5Max[1] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 2: (");
      print(evento5Min[1]); print(", "); print(evento5Max[1]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta3")))    //referente Porta 3
    {
      evento5Min[2] = theEvent.getController().getArrayValue(0);
      evento5Max[2] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 3: (");
      print(evento5Min[2]); print(", "); print(evento5Max[2]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta4")))    //referente Porta 4
    {
      evento5Min[3] = theEvent.getController().getArrayValue(0);
      evento5Max[3] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 4: (");
      print(evento5Min[3]); print(", "); print(evento5Max[3]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta5")))    //referente Porta 5
    {
      evento5Min[4] = theEvent.getController().getArrayValue(0);
      evento5Max[4] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 5: (");
      print(evento5Min[4]); print(", "); print(evento5Max[4]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta6")))    //referente Porta 6
    {
      evento5Min[5] = theEvent.getController().getArrayValue(0);
      evento5Max[5] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 6: (");
      print(evento5Min[5]); print(", "); print(evento5Max[5]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta7")))    //referente Porta 7
    {
      evento5Min[6] = theEvent.getController().getArrayValue(0);
      evento5Max[6] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 7: (");
      print(evento5Min[6]); print(", "); print(evento5Max[6]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta8")))    //referente Porta 8
    {
      evento5Min[7] = theEvent.getController().getArrayValue(0);
      evento5Max[7] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 8: (");
      print(evento5Min[7]); print(", "); print(evento5Max[7]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta9")))    //referente Porta 9
    {
      evento5Min[8] = theEvent.getController().getArrayValue(0);
      evento5Max[8] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 9: (");
      print(evento5Min[8]); print(", "); print(evento5Max[8]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta10")))    //referente Porta 10
    {
      evento5Min[9] = theEvent.getController().getArrayValue(0);
      evento5Max[9] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 10: (");
      print(evento5Min[9]); print(", "); print(evento5Max[9]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta11")))    //referente Porta 11
    {
      evento5Min[10] = theEvent.getController().getArrayValue(0);
      evento5Max[10] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 11: (");
      print(evento5Min[10]); print(", "); print(evento5Max[10]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_5_Porta12")))    //referente Porta 12
    {
      evento5Min[11] = theEvent.getController().getArrayValue(0);
      evento5Max[11] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 12: (");
      print(evento5Min[11]); print(", "); print(evento5Max[11]); println(")");
    }
    
    
    ////////////////////////////     EVENTO 6       /////////////////////////////////////       
    if(theEvent.isFrom(cp5.getController("evento_6_default")))    //referente evento6 Porta 1
    {
      evento6Min[0] = theEvent.getController().getArrayValue(0);
      evento6Max[0] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 1: (");
      print(evento6Min[0]); print(", "); print(evento6Max[0]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_6_Porta2")))    //referente Porta 2
    {
      evento6Min[1] = theEvent.getController().getArrayValue(0);
      evento6Max[1] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 2: (");
      print(evento6Min[1]); print(", "); print(evento6Max[1]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_6_Porta3")))    //referente Porta 3
    {
      evento6Min[2] = theEvent.getController().getArrayValue(0);
      evento6Max[2] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 3: (");
      print(evento6Min[2]); print(", "); print(evento6Max[2]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_6_Porta4")))    //referente Porta 4
    {
      evento6Min[3] = theEvent.getController().getArrayValue(0);
      evento6Max[3] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 4: (");
      print(evento6Min[3]); print(", "); print(evento6Max[3]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_6_Porta5")))    //referente Porta 5
    {
      evento6Min[4] = theEvent.getController().getArrayValue(0);
      evento6Max[4] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 5: (");
      print(evento6Min[4]); print(", "); print(evento6Max[4]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_6_Porta6")))    //referente Porta 6
    {
      evento6Min[5] = theEvent.getController().getArrayValue(0);
      evento6Max[5] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 6: (");
      print(evento6Min[5]); print(", "); print(evento6Max[5]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_6_Porta7")))    //referente Porta 7
    {
      evento6Min[6] = theEvent.getController().getArrayValue(0);
      evento6Max[6] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 7: (");
      print(evento6Min[6]); print(", "); print(evento6Max[6]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_6_Porta8")))    //referente Porta 8
    {
      evento6Min[7] = theEvent.getController().getArrayValue(0);
      evento6Max[7] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 8: (");
      print(evento6Min[7]); print(", "); print(evento6Max[7]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_6_Porta9")))    //referente Porta 9
    {
      evento6Min[8] = theEvent.getController().getArrayValue(0);
      evento6Max[8] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 9: (");
      print(evento6Min[8]); print(", "); print(evento6Max[8]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_6_Porta10")))    //referente Porta 10
    {
      evento6Min[9] = theEvent.getController().getArrayValue(0);
      evento6Max[9] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 10: (");
      print(evento6Min[9]); print(", "); print(evento6Max[9]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_6_Porta11")))    //referente Porta 11
    {
      evento6Min[10] = theEvent.getController().getArrayValue(0);
      evento6Max[10] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 11: (");
      print(evento6Min[10]); print(", "); print(evento6Max[10]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_6_Porta12")))    //referente Porta 12
    {
      evento6Min[11] = theEvent.getController().getArrayValue(0);
      evento6Max[11] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 12: (");
      print(evento6Min[11]); print(", "); print(evento6Max[11]); println(")");
    }
    
    
    ////////////////////////////     EVENTO 7       /////////////////////////////////////       
    if(theEvent.isFrom(cp5.getController("evento_7_default")))    //referente evento7 Porta 1
    {
      evento7Min[0] = theEvent.getController().getArrayValue(0);
      evento7Max[0] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 1: (");
      print(evento7Min[0]); print(", "); print(evento7Max[0]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_7_Porta2")))    //referente Porta 2
    {
      evento7Min[1] = theEvent.getController().getArrayValue(0);
      evento7Max[1] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 2: (");
      print(evento7Min[1]); print(", "); print(evento7Max[1]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_7_Porta3")))    //referente Porta 3
    {
      evento7Min[2] = theEvent.getController().getArrayValue(0);
      evento7Max[2] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 3: (");
      print(evento7Min[2]); print(", "); print(evento7Max[2]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_7_Porta4")))    //referente Porta 4
    {
      evento7Min[3] = theEvent.getController().getArrayValue(0);
      evento7Max[3] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 4: (");
      print(evento7Min[3]); print(", "); print(evento7Max[3]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_7_Porta5")))    //referente Porta 5
    {
      evento7Min[4] = theEvent.getController().getArrayValue(0);
      evento7Max[4] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 5: (");
      print(evento7Min[4]); print(", "); print(evento7Max[4]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_7_Porta6")))    //referente Porta 6
    {
      evento7Min[5] = theEvent.getController().getArrayValue(0);
      evento7Max[5] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 6: (");
      print(evento7Min[5]); print(", "); print(evento7Max[5]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_7_Porta7")))    //referente Porta 7
    {
      evento7Min[6] = theEvent.getController().getArrayValue(0);
      evento7Max[6] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 7: (");
      print(evento7Min[6]); print(", "); print(evento7Max[6]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_7_Porta8")))    //referente Porta 8
    {
      evento7Min[7] = theEvent.getController().getArrayValue(0);
      evento7Max[7] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 8: (");
      print(evento7Min[7]); print(", "); print(evento7Max[7]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_7_Porta9")))    //referente Porta 9
    {
      evento7Min[8] = theEvent.getController().getArrayValue(0);
      evento7Max[8] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 9: (");
      print(evento7Min[8]); print(", "); print(evento7Max[8]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_7_Porta10")))    //referente Porta 10
    {
      evento7Min[9] = theEvent.getController().getArrayValue(0);
      evento7Max[9] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 10: (");
      print(evento7Min[9]); print(", "); print(evento7Max[9]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_7_Porta11")))    //referente Porta 11
    {
      evento7Min[10] = theEvent.getController().getArrayValue(0);
      evento7Max[10] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 11: (");
      print(evento7Min[10]); print(", "); print(evento7Max[10]); println(")");
    }
    else if(theEvent.isFrom(cp5.getController("evento_7_Porta12")))    //referente Porta 12
    {
      evento7Min[11] = theEvent.getController().getArrayValue(0);
      evento7Max[11] = theEvent.getController().getArrayValue(1);
      print("Mínimo e máximo do Evento 1 Porta 12: (");
      print(evento7Min[11]); print(", "); print(evento7Max[11]); println(")");
    }


  ///////////////////////////////////////////////////////////////////////
 // Gerenciando Knobs de tempo Máximo p/ setar tempo máximo de EVENTO //
///////////////////////////////////////////////////////////////////////

  if(theEvent.isFrom("knobTempoMaximo_default"))
  {
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_default").setMax(novoMaximo);
    cp5.getController("evento_2_default").setMax(novoMaximo);
    cp5.getController("evento_3_default").setMax(novoMaximo);
    cp5.getController("evento_4_default").setMax(novoMaximo);
    cp5.getController("evento_5_default").setMax(novoMaximo);
    cp5.getController("evento_6_default").setMax(novoMaximo);
    cp5.getController("evento_7_default").setMax(novoMaximo);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta2"))
  {
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta2").setMax(novoMaximo);
    cp5.getController("evento_2_Porta2").setMax(novoMaximo);
    cp5.getController("evento_3_Porta2").setMax(novoMaximo);
    cp5.getController("evento_4_Porta2").setMax(novoMaximo);
    cp5.getController("evento_5_Porta2").setMax(novoMaximo);
    cp5.getController("evento_6_Porta2").setMax(novoMaximo);
    cp5.getController("evento_7_Porta2").setMax(novoMaximo);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta3"))
  {
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta3").setMax(novoMaximo);
    cp5.getController("evento_2_Porta3").setMax(novoMaximo);
    cp5.getController("evento_3_Porta3").setMax(novoMaximo);
    cp5.getController("evento_4_Porta3").setMax(novoMaximo);
    cp5.getController("evento_5_Porta3").setMax(novoMaximo);
    cp5.getController("evento_6_Porta3").setMax(novoMaximo);
    cp5.getController("evento_7_Porta3").setMax(novoMaximo);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta4"))
  {
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta4").setMax(novoMaximo);
    cp5.getController("evento_2_Porta4").setMax(novoMaximo);
    cp5.getController("evento_3_Porta4").setMax(novoMaximo);
    cp5.getController("evento_4_Porta4").setMax(novoMaximo);
    cp5.getController("evento_5_Porta4").setMax(novoMaximo);
    cp5.getController("evento_6_Porta4").setMax(novoMaximo);
    cp5.getController("evento_7_Porta4").setMax(novoMaximo);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta5"))
  {
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta5").setMax(novoMaximo);
    cp5.getController("evento_2_Porta5").setMax(novoMaximo);
    cp5.getController("evento_3_Porta5").setMax(novoMaximo);
    cp5.getController("evento_4_Porta5").setMax(novoMaximo);
    cp5.getController("evento_5_Porta5").setMax(novoMaximo);
    cp5.getController("evento_6_Porta5").setMax(novoMaximo);
    cp5.getController("evento_7_Porta5").setMax(novoMaximo);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta6"))
  {
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta6").setMax(novoMaximo);
    cp5.getController("evento_2_Porta6").setMax(novoMaximo);
    cp5.getController("evento_3_Porta6").setMax(novoMaximo);
    cp5.getController("evento_4_Porta6").setMax(novoMaximo);
    cp5.getController("evento_5_Porta6").setMax(novoMaximo);
    cp5.getController("evento_6_Porta6").setMax(novoMaximo);
    cp5.getController("evento_7_Porta6").setMax(novoMaximo);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta7"))
  {
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta7").setMax(novoMaximo);
    cp5.getController("evento_2_Porta7").setMax(novoMaximo);
    cp5.getController("evento_3_Porta7").setMax(novoMaximo);
    cp5.getController("evento_4_Porta7").setMax(novoMaximo);
    cp5.getController("evento_5_Porta7").setMax(novoMaximo);
    cp5.getController("evento_6_Porta7").setMax(novoMaximo);
    cp5.getController("evento_7_Porta7").setMax(novoMaximo);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta8"))
  {
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta8").setMax(novoMaximo);
    cp5.getController("evento_2_Porta8").setMax(novoMaximo);
    cp5.getController("evento_3_Porta8").setMax(novoMaximo);
    cp5.getController("evento_4_Porta8").setMax(novoMaximo);
    cp5.getController("evento_5_Porta8").setMax(novoMaximo);
    cp5.getController("evento_6_Porta8").setMax(novoMaximo);
    cp5.getController("evento_7_Porta8").setMax(novoMaximo);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta9"))
  {
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta9").setMax(novoMaximo);
    cp5.getController("evento_2_Porta9").setMax(novoMaximo);
    cp5.getController("evento_3_Porta9").setMax(novoMaximo);
    cp5.getController("evento_4_Porta9").setMax(novoMaximo);
    cp5.getController("evento_5_Porta9").setMax(novoMaximo);
    cp5.getController("evento_6_Porta9").setMax(novoMaximo);
    cp5.getController("evento_7_Porta9").setMax(novoMaximo);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta10"))
  {
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta10").setMax(novoMaximo);
    cp5.getController("evento_2_Porta10").setMax(novoMaximo);
    cp5.getController("evento_3_Porta10").setMax(novoMaximo);
    cp5.getController("evento_4_Porta10").setMax(novoMaximo);
    cp5.getController("evento_5_Porta10").setMax(novoMaximo);
    cp5.getController("evento_6_Porta10").setMax(novoMaximo);
    cp5.getController("evento_7_Porta10").setMax(novoMaximo);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta11"))
  {
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta11").setMax(novoMaximo);
    cp5.getController("evento_2_Porta11").setMax(novoMaximo);
    cp5.getController("evento_3_Porta11").setMax(novoMaximo);
    cp5.getController("evento_4_Porta11").setMax(novoMaximo);
    cp5.getController("evento_5_Porta11").setMax(novoMaximo);
    cp5.getController("evento_6_Porta11").setMax(novoMaximo);
    cp5.getController("evento_7_Porta11").setMax(novoMaximo);
  }
  else if(theEvent.isFrom("knobTempoMaximo_Porta12"))
  {
    float novoMaximo = theEvent.getController().getValue();
    cp5.getController("evento_1_Porta12").setMax(novoMaximo);
    cp5.getController("evento_2_Porta12").setMax(novoMaximo);
    cp5.getController("evento_3_Porta12").setMax(novoMaximo);
    cp5.getController("evento_4_Porta12").setMax(novoMaximo);
    cp5.getController("evento_5_Porta12").setMax(novoMaximo);
    cp5.getController("evento_6_Porta12").setMax(novoMaximo);
    cp5.getController("evento_7_Porta12").setMax(novoMaximo);
  }


  /////////////////////////////////////
 //  Gerenciando botões de INICIAR  //
/////////////////////////////////////

  if(theEvent.isFrom("iniciar_default"))    //responde ao acionar botão INICIAR
  {
    println("Enviando eventos tela Porta 1");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta2"))
  {
    println("Enviando eventos tela Porta 2");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta3"))
  {
    println("Enviando eventos tela Porta 3");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta4"))
  {
    println("Enviando eventos tela Porta 4");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta5"))
  {
    println("Enviando eventos tela Porta 5");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta6"))
  {
    println("Enviando eventos tela Porta 6");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta7"))
  {
    println("Enviando eventos tela Porta 7");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta8"))
  {
    println("Enviando eventos tela Porta 8");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta9"))
  {
    println("Enviando eventos tela Porta 9");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta10"))
  {
    println("Enviando eventos tela Porta 10");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta11"))
  {
    println("Enviando eventos tela Porta 11");
    iniciarOperacao();
  }
  else if(theEvent.isFrom("iniciar_Porta12"))
  {
    println("Enviando eventos tela Porta 12");
    iniciarOperacao();
  }
}

  ////////////////////////////////////
 //  Gerenciando toogle de TENSÃO  //
////////////////////////////////////

public void tensao_default(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 1\n");
  setarTensaoPorta(1, estadoToggle);
}

public void tensao_Porta2(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 2");
  setarTensaoPorta(2, estadoToggle);
}

public void tensao_Porta3(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 3");
  setarTensaoPorta(3, estadoToggle);
}

public void tensao_Porta4(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 4");
  setarTensaoPorta(4, estadoToggle);
}

public void tensao_Porta5(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 5");
  setarTensaoPorta(5, estadoToggle);
}

public void tensao_Porta6(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 6");
  setarTensaoPorta(6, estadoToggle);
}

public void tensao_Porta7(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 7");
  setarTensaoPorta(7, estadoToggle);
}

public void tensao_Porta8(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 8");
  setarTensaoPorta(8, estadoToggle);
}

public void tensao_Porta9(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 9");
  setarTensaoPorta(9, estadoToggle);
}

public void tensao_Porta10(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 10");
  setarTensaoPorta(10, estadoToggle);
}

public void tensao_Porta11(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 11");
  setarTensaoPorta(11, estadoToggle);
}

public void tensao_Porta12(boolean estadoToggle)
{
  println("Enviando mensagem de setar tensão da Porta 12");
  setarTensaoPorta(12, estadoToggle);
}




//===========================================================================================
//  Tempo Máximo - seta o Evento para o tempo máximo determinado pelo knob
//===========================================================================================

public void knobTempoMaximo(int theValue) 
{
  println("a knob event. Value = "+ theValue);
  int novoMax = theValue;
  rangeEvento1.setMax(novoMax);    //esta instrução está retornando um erro no console
}


//===========================================================================================
//  Gerador do elemento de interface Tabs (que seleciona a Porta a ser configurada)
//
//===========================================================================================
public void gerarTabs()
{
  PFont pfont = createFont("Arial",20,true); // use true/false for smooth/no-smooth
  ControlFont font_min = new ControlFont(pfont, 12);
  
  cp5.getTab("default")
     .activateEvent(true)
     .setLabel("     1")
     .setHeight(50)
     .setWidth(50)
     .setId(1)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta2")
     .activateEvent(true)
     .setLabel("     2")
     .setHeight(50)
     .setWidth(50)
     .setId(2)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta3")
     .activateEvent(true)
     .setLabel("     3")
     .setHeight(50)
     .setWidth(50)
     .setId(2)
     .getCaptionLabel()
     .setFont(font_min)
     ;
  
  cp5.addTab("Porta4")
     .activateEvent(true)
     .setLabel("     4")
     .setHeight(50)
     .setWidth(50)
     .setId(2)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta5")
     .activateEvent(true)
     .setLabel("     5")
     .setHeight(50)
     .setWidth(50)
     .setId(2)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta6")
     .activateEvent(true)
     .setLabel("     6")
     .setHeight(50)
     .setWidth(50)
     .setId(2)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta7")
     .activateEvent(true)
     .setLabel("     7")
     .setHeight(50)
     .setWidth(50)
     .setId(1)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta8")
     .activateEvent(true)
     .setLabel("     8")
     .setHeight(50)
     .setWidth(50)
     .setId(2)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta9")
     .activateEvent(true)
     .setLabel("     9")
     .setHeight(50)
     .setWidth(50)
     .setId(2)
     .getCaptionLabel()
     .setFont(font_min)
     ;
  
  cp5.addTab("Porta10")
     .activateEvent(true)
     .setLabel("    10")
     .setHeight(50)
     .setWidth(50)
     .setId(2)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta11")
     .activateEvent(true)
     .setLabel("    11")
     .setHeight(50)
     .setWidth(50)
     .setId(2)
     .getCaptionLabel()
     .setFont(font_min)
     ;

  cp5.addTab("Porta12")
     .activateEvent(true)
     .setLabel("    12")
     .setHeight(50)
     .setWidth(50)
     .setId(2)
     .getCaptionLabel()
     .setFont(font_min)
     ;
}

//===========================================================================================
//  gerarInterface - gera elementos da Interface para uma Tab
//
//===========================================================================================

public void gerarInterface(String tab)
{
  

  PFont pfont = createFont("Arial",20,true); // use true/false for smooth/no-smooth
  ControlFont font = new ControlFont(pfont, 20);
  ControlFont font_min = new ControlFont(pfont, 12);
  ControlFont font_med = new ControlFont(pfont, 16);
  
  cp5.addTextlabel("labelSaida" + "_" + tab)
     .setText("PORTAS")
     .setPosition(655, 10)
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;

  cp5.addTextlabel("labelTensao" + "_" + tab)
     .setText("TENSÃO")
     .setPosition( (toogleTensaoPosX + 80) , toogleTensaoPosY )
     .setColorValue(255)
     .setFont(font)
     .moveTo(tab)
     ;
  
  cp5.addButton("iniciar" + "_" + tab)
     .setPosition(900,50)
     .setSize(82,82)
     .setLabel("iniciar")
     .setFont(font_med)
     .isPressed()
     ;
  cp5.getController("iniciar" + "_" + tab).moveTo(tab);

  cp5.addKnob("knobTempoMaximo" + "_" + tab)
     .setRange(0,18000)
     .setValue((int)rangeMax)
     .setPosition(120, 320)
     .setRadius(80)
     .setLabel("Tempo Máximo")
     .setFont(font)
     .moveTo(tab)
     ;
                   
  cp5.addToggle("tensao" + "_" + tab)
     .setPosition( toogleTensaoPosX , toogleTensaoPosY )
     .setSize(72, 26)
     .setValue(true)
     .setMode(ControlP5.SWITCH)
     .setLabel(" 12V  -  24V")
     .setFont(font_min)
     .moveTo(tab)
     ;

  cp5.addRange("evento_1" + "_" + tab)
    .setBroadcast(false) 
    .setPosition(posX, posY)
    .setSize(500, 42)
    .setHandleSize(10)
    .setRange(rangeMin, rangeMax)
    .setRangeValues(rangeMin, rangeMin)
    .setLabel("Evento 1")
    .setFont(font)
    .setBroadcast(true)
    .moveTo(tab)
    ;

  cp5.addRange("evento_2" + "_" + tab)
    .setBroadcast(false) 
    .setPosition(posX, posY+52)
    .setSize(500, 42)
    .setHandleSize(10)
    .setRange(rangeMin, rangeMax)
    .setRangeValues(rangeMin, rangeMin)
    .setLabel("Evento 2")
    .setFont(font)
    .setBroadcast(true)
    .moveTo(tab)
    ;
    
      cp5.addRange("evento_3" + "_" + tab)
    .setBroadcast(false) 
    .setPosition(posX, posY+104)
    .setSize(500, 42)
    .setHandleSize(10)
    .setRange(rangeMin, rangeMax)
    .setRangeValues(rangeMin, rangeMin)
    .setLabel("Evento 3")
    .setFont(font)
    .setBroadcast(true)
    .moveTo(tab)
    ;

  cp5.addRange("evento_4" + "_" + tab)
    .setBroadcast(false) 
    .setPosition(posX, posY+156)
    .setSize(500, 42)
    .setHandleSize(10)
    .setRange(rangeMin, rangeMax)
    .setRangeValues(rangeMin, rangeMin)
    .setLabel("Evento 4")
    .setFont(font)
    .setBroadcast(true)
    .moveTo(tab)
    ;
    
    cp5.addRange("evento_5" + "_" + tab)
    .setBroadcast(false) 
    .setPosition(posX, posY+212)
    .setSize(500, 42)
    .setHandleSize(10)
    .setRange(rangeMin, rangeMax)
    .setRangeValues(rangeMin, rangeMin)
    .setLabel("Evento 5")
    .setFont(font)
    .setBroadcast(true)
    .moveTo(tab)
    ;
    
      cp5.addRange("evento_6" + "_" + tab)
    .setBroadcast(false) 
    .setPosition(posX, posY+264)
    .setSize(500, 42)
    .setHandleSize(10)
    .setRange(rangeMin, rangeMax)
    .setRangeValues(rangeMin, rangeMin)
    .setLabel("Evento 6")
    .setFont(font)
    .setBroadcast(true)
    .moveTo(tab)
    ;

  cp5.addRange("evento_7" + "_" + tab)
    .setBroadcast(false) 
    .setPosition(posX, posY+316)
    .setSize(500, 42)
    .setHandleSize(10)
    .setRange(rangeMin, rangeMax)
    .setRangeValues(rangeMin, rangeMin)
    .setLabel("Evento 7")
    .setFont(font)
    .setBroadcast(true)
    .moveTo(tab)
    ;
}
//===========================================================================================
/*                  --------------  Fim do Programa  --------------                        */
//===========================================================================================
  public void settings() {  size(1024,600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "normaeProtoInterface_01_OSC_usandoTAB" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
