

function M.list(fv)
    return fv
end

function M.setaEvento()
    print('Eventos Setados em Normae')
end