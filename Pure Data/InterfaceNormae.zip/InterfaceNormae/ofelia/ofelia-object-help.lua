M.myBoolean = true
M.myNumber = 42
M.myString = "Foo"
M.myTable = {1, 2, 3, 4}

function M.myFunction(f)
return f * 2
end