# ArduinoMultithreading
create multitasking applications using Arduino
![example output](https://github.com/ArabicRobotics/ArduinoMultithreading/blob/master/Article.png?raw=true)
